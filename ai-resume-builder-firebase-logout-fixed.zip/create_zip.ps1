$src = 'C:\Users\mrvam\.gemini\antigravity\scratch\ai-resume-builder'
$dest1 = 'C:\Users\mrvam\.gemini\antigravity\scratch\ai-resume-builder\ai-resume-builder.zip'
$dest2 = 'C:\Users\mrvam\.gemini\antigravity\scratch\ai-resume-builder.zip'

if (Test-Path $dest1) { Remove-Item -Force $dest1 }
if (Test-Path $dest2) { Remove-Item -Force $dest2 }

$items = Get-ChildItem -Path $src -Exclude 'node_modules', '*.zip'

Write-Host "Compressing $($items.Count) files and directories..."
Compress-Archive -Path $items.FullName -DestinationPath $dest1 -Force
Copy-Item -Path $dest1 -Destination $dest2 -Force

Write-Host "Success! ZIP created at:"
Get-Item $dest1, $dest2 | Select-Object FullName, Length
