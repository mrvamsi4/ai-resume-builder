// js/templates.js

const TEMPLATES_CATALOG = [
  {
    id: 'modern',
    name: 'Modern Tech',
    badge: 'Popular & ATS Approved',
    badgeClass: 'badge-primary',
    bestFor: 'Software Engineers, Product Managers & Tech Startups',
    description: 'Clean sans-serif typography with sleek indigo section accents, structured skill categories, and modern action-verb bullet formatting.',
    features: ['High ATS parser score (98%)', 'Compact 1-page layout', 'Organized skill tags', 'Mobile responsive'],
    accentColor: '#4F46E5'
  },
  {
    id: 'professional',
    name: 'Corporate Professional',
    badge: 'Executive & Traditional',
    badgeClass: 'badge-info',
    bestFor: 'Finance, Consulting, Enterprise IT & Operations',
    description: 'Distinguished deep navy headers, serif titles, and classic dividing rules favored by Fortune 500 recruiters and enterprise applicant tracking systems.',
    features: ['Recruiter standard layout', 'Formal serif headings', 'Clear chronological progression', 'Conservative styling'],
    accentColor: '#1E3A8A'
  },
  {
    id: 'minimal',
    name: 'Minimalist Clean',
    badge: 'Zero-Distraction',
    badgeClass: 'badge-success',
    bestFor: 'Engineering, Research, Data Science & Academia',
    description: 'Monochromatic high-whitespace design strictly focusing on text clarity and content impact. Free of non-standard graphic elements for instant parser parsing.',
    features: ['100% Monochromatic', 'Maximum readability', 'Uncluttered spacing', 'Ultra-fast scanner extraction'],
    accentColor: '#0F172A'
  },
  {
    id: 'creative',
    name: 'Creative Impact',
    badge: 'Modern Visuals',
    badgeClass: 'badge-warning',
    bestFor: 'UI/UX Designers, Frontend Developers & Marketing',
    description: 'Features a vibrant top gradient banner and stylized section dividers that immediately stand out in hiring managers’ inboxes while preserving ATS tags.',
    features: ['Gradient header accent', 'Strong personal branding', 'Portfolio prominence', 'Skill chip badges'],
    accentColor: '#7C3AED'
  },
  {
    id: 'executive',
    name: 'Executive Leadership',
    badge: 'Senior & Management',
    badgeClass: 'badge-primary',
    bestFor: 'Tech Leads, Engineering Managers & Directors',
    description: 'Sophisticated emerald and slate corporate styling with a dedicated executive summary box and leadership metrics emphasis.',
    features: ['Executive summary emphasis', 'Team & budget metrics', 'Distinguished sidebar rule', 'Board-ready aesthetic'],
    accentColor: '#059669'
  },
  {
    id: 'ats-classic',
    name: 'ATS Classic (Standard)',
    badge: 'Guaranteed Parse Rate',
    badgeClass: 'badge-success',
    bestFor: 'Fresh Graduates, Government, Large Enterprises & Internships',
    description: 'Strict, single-column plain text architecture utilizing standard bullet symbols and universal typography. Compatible with every ATS legacy system worldwide.',
    features: ['Universal ATS compatibility', 'Zero formatting friction', 'Standard bullet glyphs', 'Optimal for automated parsers'],
    accentColor: '#374151'
  }
];

document.addEventListener('DOMContentLoaded', () => {
  renderTemplatesGallery();
});

function renderTemplatesGallery() {
  const grid = document.getElementById('templatesGalleryGrid');
  if (!grid) return;
  grid.innerHTML = '';

  TEMPLATES_CATALOG.forEach(t => {
    const card = document.createElement('div');
    card.className = 'card template-card';
    card.style.display = 'flex';
    card.style.flexDirection = 'column';
    card.style.justifyContent = 'space-between';
    card.style.transition = 'transform 0.2s ease, box-shadow 0.2s ease';

    card.innerHTML = `
      <div>
        <div style="height: 140px; background: ${t.accentColor}; border-radius: var(--radius-md); margin-bottom: 1.25rem; display: flex; align-items: center; justify-content: center; color: #fff; position: relative; overflow: hidden;">
          <div style="position: absolute; inset: 0; background: radial-gradient(circle at 80% 20%, rgba(255,255,255,0.2) 0%, transparent 60%);"></div>
          <div style="text-align: center; z-index: 2; padding: 1rem;">
            <span style="font-size: 2rem;">📄</span>
            <div style="font-family: var(--font-heading); font-weight: 700; font-size: 1.15rem; margin-top: 0.25rem;">${escapeHtml(t.name)}</div>
          </div>
        </div>

        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.75rem;">
          <span class="badge ${t.badgeClass}">${escapeHtml(t.badge)}</span>
          <span style="font-size: 0.8rem; color: var(--text-muted);">A4 Formatted</span>
        </div>

        <h3 style="font-size: 1.2rem; margin-bottom: 0.5rem;">${escapeHtml(t.name)}</h3>
        <p style="font-size: 0.875rem; color: var(--text-muted); margin-bottom: 1rem; line-height: 1.5;">${escapeHtml(t.description)}</p>

        <div style="margin-bottom: 1.25rem;">
          <span style="font-size: 0.75rem; font-weight: 700; color: var(--text-main); text-transform: uppercase; letter-spacing: 0.05em; display: block; margin-bottom: 0.5rem;">Key Features</span>
          <ul style="list-style: none; display: flex; flex-direction: column; gap: 0.35rem; font-size: 0.85rem; color: var(--text-muted);">
            ${t.features.map(f => `<li>✓ ${escapeHtml(f)}</li>`).join('')}
          </ul>
        </div>
      </div>

      <div style="display: flex; gap: 0.75rem; margin-top: 1rem; padding-top: 1rem; border-top: 1px solid var(--border-light);">
        <button class="btn btn-primary" style="flex: 1;" onclick="useTemplate('${t.id}')">
          Use This Template
        </button>
        <button class="btn btn-secondary" onclick="previewTemplateInBuilder('${t.id}')" title="Preview with Sample Data">
          👁️
        </button>
      </div>
    `;

    grid.appendChild(card);
  });
}

window.useTemplate = function(templateId) {
  window.location.href = `builder.html?new=true&template=${templateId}`;
};

window.previewTemplateInBuilder = function(templateId) {
  window.location.href = `builder.html?template=${templateId}&preview=true`;
};

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>"']/g, function(m) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
  });
}
