// js/profile.js

document.addEventListener('DOMContentLoaded', async () => {
  const user = await window.AppAuth.ready;
  if (!user) {
    window.location.href = 'login.html';
    return;
  }

  loadUserProfile(user);

  const profileForm = document.getElementById('profileForm');
  if (profileForm) {
    profileForm.addEventListener('submit', (e) => {
      e.preventDefault();
      saveUserProfile();
    });
  }
});

function loadUserProfile(user) {
  setVal('profileFullName', user.displayName || user.name || 'Alex Morgan');
  setVal('profileTitle', user.title || 'Full Stack Software Engineer');
  setVal('profileEmail', user.email || 'alex.morgan@email.com');
  setVal('profilePhone', user.phone || '+1 (555) 234-5678');
  setVal('profileLocation', user.location || 'San Francisco, CA');
  setVal('profileLinkedin', user.linkedin || 'https://linkedin.com/in/alexmorgan');
  setVal('profileGithub', user.github || 'https://github.com/alexmorgan');
  setVal('profilePortfolio', user.portfolio || 'https://alexmorgan.dev');

  const avatarInitial = document.getElementById('profileAvatarInitial');
  if (avatarInitial) {
    if (user.photoURL) {
      avatarInitial.innerHTML = `<img src="${user.photoURL}" alt="${user.displayName || 'User'}" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">`;
    } else {
      avatarInitial.textContent = (user.displayName || user.name || 'A').charAt(0).toUpperCase();
    }
  }

  const profileNameHeader = document.getElementById('profileHeaderName');
  if (profileNameHeader) {
    profileNameHeader.textContent = user.displayName || user.name || 'Alex Morgan';
  }
}

function saveUserProfile() {
  const user = window.AppAuth.getCurrentUser() || {};
  const updatedUser = {
    ...user,
    displayName: getVal('profileFullName'),
    title: getVal('profileTitle'),
    email: getVal('profileEmail'),
    phone: getVal('profilePhone'),
    location: getVal('profileLocation'),
    linkedin: getVal('profileLinkedin'),
    github: getVal('profileGithub'),
    portfolio: getVal('profilePortfolio')
  };

  localStorage.setItem('resumeai_current_user', JSON.stringify(updatedUser));
  window.showToast('Profile updated successfully!', 'success');
  loadUserProfile(updatedUser);
}

function setVal(id, val) {
  const el = document.getElementById(id);
  if (el) el.value = val || '';
}

function getVal(id) {
  const el = document.getElementById(id);
  return el ? el.value.trim() : '';
}
