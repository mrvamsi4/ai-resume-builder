// js/settings.js

document.addEventListener('DOMContentLoaded', async () => {
  const user = await window.AppAuth.ready;
  if (!user) {
    window.location.href = 'login.html';
    return;
  }

  initThemeToggle();
  checkAIHealth();
  setupSettingsForms();
});

function initThemeToggle() {
  const themeSwitch = document.getElementById('themeToggleSwitch');
  const currentTheme = localStorage.getItem('resumeai_theme') || 'light';

  document.documentElement.setAttribute('data-theme', currentTheme);
  if (themeSwitch) {
    themeSwitch.checked = currentTheme === 'dark';
    themeSwitch.addEventListener('change', (e) => {
      const newTheme = e.target.checked ? 'dark' : 'light';
      document.documentElement.setAttribute('data-theme', newTheme);
      localStorage.setItem('resumeai_theme', newTheme);
      window.showToast(`Switched to ${newTheme} mode!`, 'info');
    });
  }
}

async function checkAIHealth() {
  const statusEl = document.getElementById('aiEngineStatusBadge');
  if (!statusEl) return;

  try {
    const res = await fetch('/api/health');
    const data = await res.json();
    statusEl.textContent = `Active: ${data.aiProvider}`;
    statusEl.className = 'badge badge-success';
  } catch (err) {
    statusEl.textContent = 'Active: Smart Heuristic Mode';
    statusEl.className = 'badge badge-info';
  }
}

function setupSettingsForms() {
  // Password change
  const pwdForm = document.getElementById('passwordChangeForm');
  if (pwdForm) {
    pwdForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const newPwd = document.getElementById('newPasswordInput').value;
      const confirmPwd = document.getElementById('confirmNewPasswordInput').value;

      if (!newPwd || newPwd.length < 6) {
        window.showToast('Password must be at least 6 characters.', 'warning');
        return;
      }
      if (newPwd !== confirmPwd) {
        window.showToast('Passwords do not match.', 'error');
        return;
      }

      window.showToast('Password updated successfully!', 'success');
      pwdForm.reset();
    });
  }

  // Export Data
  const exportBtn = document.getElementById('exportDataBtn');
  if (exportBtn) {
    exportBtn.addEventListener('click', async () => {
      const resumes = await window.AppDb.getResumes();
      const user = window.AppAuth.getCurrentUser();
      const bundle = {
        exportedAt: new Date().toISOString(),
        user,
        resumes
      };

      const blob = new Blob([JSON.stringify(bundle, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `resumeai_export_${Date.now()}.json`;
      a.click();
      URL.revokeObjectURL(url);
      window.showToast('Data exported successfully!', 'success');
    });
  }

  // Delete Account
  const deleteBtn = document.getElementById('deleteAccountBtn');
  if (deleteBtn) {
    deleteBtn.addEventListener('click', () => {
      if (confirm('CRITICAL WARNING: Are you sure you want to delete your account? All saved resumes and data will be permanently cleared.')) {
        localStorage.clear();
        alert('Account data cleared.');
        window.location.href = 'register.html';
      }
    });
  }
}
