// js/firebase-config.js
// Firebase Web App configuration for ResumeAI.
// These values identify the Firebase project; Firebase Auth providers and
// Security Rules control access to protected resources.

window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyCxcBz4ycbSmqMxMd17cR8vLbawwYFIGQc",
  authDomain: "resumeai-d2498.firebaseapp.com",
  projectId: "resumeai-d2498",
  storageBucket: "resumeai-d2498.firebasestorage.app",
  messagingSenderId: "478959547232",
  appId: "1:478959547232:web:c732842a07528bf1ebe405",
  measurementId: "G-5FDBHQ9YVX"
};
