// js/builder.js

// State management for current resume
let currentResume = {
  id: null,
  resumeName: 'Full Stack Software Engineer',
  template: 'modern',
  personalInfo: {
    fullName: 'Alex Morgan',
    title: 'Full Stack Software Engineer',
    email: 'alex.morgan@email.com',
    phone: '+1 (555) 234-5678',
    location: 'San Francisco, CA',
    linkedin: 'https://linkedin.com/in/alexmorgan',
    github: 'https://github.com/alexmorgan',
    portfolio: 'https://alexmorgan.dev'
  },
  summary: 'Results-driven Full Stack Engineer with 3+ years of experience designing and implementing scalable web applications, RESTful APIs, and cloud-native solutions. Proficient in JavaScript, TypeScript, React, Node.js, and PostgreSQL with a proven record of optimizing database performance by 40% and delivering robust microservices.',
  education: [
    {
      id: 'edu-1',
      degree: 'Bachelor of Science in Computer Science',
      institution: 'University of California, Berkeley',
      location: 'Berkeley, CA',
      startYear: '2019',
      endYear: '2023',
      grade: '3.85 GPA'
    }
  ],
  skills: {
    technical: 'JavaScript, TypeScript, Python, HTML5, CSS3, SQL',
    languages: 'JavaScript, TypeScript, Python, C++',
    frameworks: 'React, Node.js, Express.js, Next.js, Tailwind CSS',
    tools: 'Git, Docker, AWS (S3, EC2), Postman, Jest, CI/CD',
    soft: 'Problem Solving, Agile Collaboration, Technical Mentorship'
  },
  projects: [
    {
      id: 'proj-1',
      name: 'AI Document Intelligence Platform',
      technologies: 'Node.js, Express, React, OpenAI API, MongoDB, AWS',
      link: 'https://aidocintel.demo.com',
      github: 'https://github.com/alexmorgan/ai-doc-intel',
      description: '• Architected and deployed an end-to-end AI document classification pipeline supporting 15,000+ monthly uploads.\n• Reduced document processing time by 65% through async BullMQ workers and Redis caching.\n• Engineered secure multi-tenant role-based access control with 99.9% uptime.'
    },
    {
      id: 'proj-2',
      name: 'Real-Time Collaborative Code Editor',
      technologies: 'WebSockets, React, Node.js, Monaco Editor, Docker',
      link: 'https://codeshare-live.demo.com',
      github: 'https://github.com/alexmorgan/codeshare-live',
      description: '• Engineered a multi-user collaborative workspace with Operational Transformation supporting 50 concurrent active editors per room.\n• Implemented sub-50ms sync latency via optimized WebSocket binary framing.'
    }
  ],
  experience: [
    {
      id: 'exp-1',
      title: 'Software Engineer',
      company: 'Nexus Cloud Technologies',
      location: 'San Francisco, CA',
      startDate: 'Jun 2023',
      endDate: 'Present',
      description: '• Developed and maintained 12+ mission-critical microservices serving 200,000+ daily active users.\n• Streamlined CI/CD deployment pipelines cutting staging deployment duration from 25 mins to 7 mins.\n• Refactored SQL query bottlenecks resulting in 40% reduction in average API response time.'
    }
  ],
  certifications: [
    {
      id: 'cert-1',
      name: 'AWS Certified Solutions Architect – Associate',
      organization: 'Amazon Web Services',
      date: '2024',
      link: 'https://aws.amazon.com/verification'
    }
  ],
  achievements: [
    {
      id: 'ach-1',
      title: '1st Place Winner – HackTech 2023',
      description: 'Awarded first place among 120 teams for building an accessible AI speech assistant.'
    }
  ],
  atsScore: 88
};

// Current zoom level for preview canvas
let currentZoom = 0.75;

document.addEventListener('DOMContentLoaded', async () => {
  const user = await window.AppAuth.ready;
  if (!user) {
    window.location.href = 'login.html';
    return;
  }

  // Parse URL params
  const urlParams = new URLSearchParams(window.location.search);
  const resumeId = urlParams.get('id');
  const initialName = urlParams.get('name');
  const initialTemplate = urlParams.get('template');
  const startInPreview = urlParams.get('preview');

  if (initialName) currentResume.resumeName = decodeURIComponent(initialName);
  if (initialTemplate) currentResume.template = initialTemplate;

  // Load existing resume from backend/local storage if id provided
  if (resumeId) {
    const loaded = await window.AppDb.getResumeById(resumeId);
    if (loaded) {
      currentResume = { ...currentResume, ...loaded };
    }
  } else {
    // If user has saved profile info, customize header
    if (user.displayName) currentResume.personalInfo.fullName = user.displayName;
    if (user.email) currentResume.personalInfo.email = user.email;
    if (user.phone) currentResume.personalInfo.phone = user.phone;
    if (user.location) currentResume.personalInfo.location = user.location;
    if (initialName) currentResume.personalInfo.title = decodeURIComponent(initialName);
  }

  // Initialize UI controls
  initializeBuilderUI();
  populateFormFields();
  renderPreview();
  setupEventListeners();

  // Auto-fit zoom on load after rendering
  setTimeout(() => {
    autoFitZoom();
  }, 100);

  // Re-adjust zoom on window resize
  window.addEventListener('resize', () => {
    if (window.innerWidth > 1024) {
      autoFitZoom();
    }
  });

  if (startInPreview && window.innerWidth <= 1024) {
    switchMobileTab('preview');
  }
});

/**
 * Initialize Builder Accordions, Template Selector, Zoom
 */
function initializeBuilderUI() {
  const nameInput = document.getElementById('resumeTitleInput');
  if (nameInput) nameInput.value = currentResume.resumeName || 'Full Stack Software Engineer';

  const templateSelect = document.getElementById('templateSelector');
  if (templateSelect) templateSelect.value = currentResume.template || 'modern';
}

/**
 * Populate all form fields from currentResume state
 */
function populateFormFields() {
  // Personal Info
  const p = currentResume.personalInfo || {};
  setVal('fullName', p.fullName);
  setVal('professionalTitle', p.title);
  setVal('email', p.email);
  setVal('phone', p.phone);
  setVal('location', p.location);
  setVal('linkedin', p.linkedin);
  setVal('github', p.github);
  setVal('portfolio', p.portfolio);

  // Summary
  setVal('summaryText', currentResume.summary);

  // Skills
  const s = currentResume.skills || {};
  setVal('skillsTechnical', typeof s === 'string' ? s : (s.technical || ''));
  setVal('skillsLanguages', s.languages || '');
  setVal('skillsFrameworks', s.frameworks || '');
  setVal('skillsTools', s.tools || '');
  setVal('skillsSoft', s.soft || '');

  // Dynamic Lists
  renderEducationList();
  renderProjectsList();
  renderExperienceList();
  renderCertificationsList();
  renderAchievementsList();
}

function setVal(id, val) {
  const el = document.getElementById(id);
  if (el) el.value = val || '';
}

function getVal(id) {
  const el = document.getElementById(id);
  return el ? el.value.trim() : '';
}

// High-performance debounced preview rendering via requestAnimationFrame
let previewRafId = null;
function scheduleRenderPreview() {
  if (previewRafId) cancelAnimationFrame(previewRafId);
  previewRafId = requestAnimationFrame(() => {
    renderPreview();
  });
}

/**
 * Setup Real-time Form Event Listeners (Keystroke synchronization)
 */
function setupEventListeners() {
  // Resume Name input
  const nameInput = document.getElementById('resumeTitleInput');
  if (nameInput) {
    nameInput.addEventListener('input', (e) => {
      currentResume.resumeName = e.target.value.trim() || 'Untitled Resume';
    });
  }

  // Personal Info Inputs
  const pInputs = ['fullName', 'professionalTitle', 'email', 'phone', 'location', 'linkedin', 'github', 'portfolio'];
  pInputs.forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('input', () => {
        currentResume.personalInfo = {
          fullName: getVal('fullName'),
          title: getVal('professionalTitle'),
          email: getVal('email'),
          phone: getVal('phone'),
          location: getVal('location'),
          linkedin: getVal('linkedin'),
          github: getVal('github'),
          portfolio: getVal('portfolio')
        };
        scheduleRenderPreview();
      });
    }
  });

  // Summary input
  const summaryEl = document.getElementById('summaryText');
  if (summaryEl) {
    summaryEl.addEventListener('input', () => {
      currentResume.summary = summaryEl.value;
      scheduleRenderPreview();
    });
  }

  // Skills Inputs
  const skillInputs = ['skillsTechnical', 'skillsLanguages', 'skillsFrameworks', 'skillsTools', 'skillsSoft'];
  skillInputs.forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('input', () => {
        currentResume.skills = {
          technical: getVal('skillsTechnical'),
          languages: getVal('skillsLanguages'),
          frameworks: getVal('skillsFrameworks'),
          tools: getVal('skillsTools'),
          soft: getVal('skillsSoft')
        };
        scheduleRenderPreview();
      });
    }
  });

  // Template dropdown change
  const templateSelect = document.getElementById('templateSelector');
  if (templateSelect) {
    templateSelect.addEventListener('change', (e) => {
      currentResume.template = e.target.value;
      renderPreview();
    });
  }

  // Accordion card toggle
  document.querySelectorAll('.section-card-header').forEach(header => {
    header.addEventListener('click', () => {
      header.classList.toggle('open');
      const body = header.nextElementSibling;
      if (body) body.classList.toggle('open');
      const chevron = header.querySelector('.accordion-chevron');
      if (chevron) {
        chevron.textContent = header.classList.contains('open') ? '▲' : '▼';
      }
    });
  });

  // Zoom controls
  document.getElementById('zoomInBtn')?.addEventListener('click', () => {
    if (currentZoom < 1.3) {
      currentZoom = Math.min(1.3, Number((currentZoom + 0.08).toFixed(2)));
      updateZoomDisplay(true);
    }
  });

  document.getElementById('zoomOutBtn')?.addEventListener('click', () => {
    if (currentZoom > 0.4) {
      currentZoom = Math.max(0.4, Number((currentZoom - 0.08).toFixed(2)));
      updateZoomDisplay(true);
    }
  });
}

/**
 * Auto-Fit Zoom calculation: perfectly fits the 210mm (~794px) A4 sheet
 * inside the available width of the preview pane with comfortable padding.
 */
window.autoFitZoom = function() {
  const viewport = document.getElementById('previewScrollViewport');
  if (!viewport) return;

  const availableWidth = viewport.clientWidth - 48; // 24px padding on each side
  const a4WidthPx = 794; // 210mm at 96 DPI
  const fitRatio = availableWidth / a4WidthPx;

  // Clamp zoom between 45% and 100%
  currentZoom = Math.min(1.0, Math.max(0.45, Number(fitRatio.toFixed(2))));
  updateZoomDisplay(true);
};

window.setPresetZoom = function(level) {
  currentZoom = level;
  updateZoomDisplay(true);
};

let cachedPaperHeight = 1123;

function updateZoomDisplay(forceMeasure = false) {
  const paperWrapper = document.getElementById('resumePaperWrapper');
  const scaler = document.getElementById('resumePaperScaler');
  const zoomText = document.getElementById('zoomLevelText');

  const unscaledW = 794; // 210mm in px
  if (forceMeasure && paperWrapper) {
    cachedPaperHeight = Math.max(1123, paperWrapper.offsetHeight);
  }

  if (paperWrapper) {
    paperWrapper.style.transform = `scale(${currentZoom})`;
  }
  if (scaler) {
    scaler.style.width = `${Math.round(unscaledW * currentZoom)}px`;
    scaler.style.height = `${Math.round(cachedPaperHeight * currentZoom)}px`;
  }
  if (zoomText) {
    zoomText.textContent = `${Math.round(currentZoom * 100)}%`;
  }
}

/**
 * Layout Mode Toggle: Standard 50/50 Split vs Big Preview Focus
 */
window.setLayoutMode = function(mode) {
  const workspace = document.getElementById('builderWorkspace');
  const btnSplit = document.getElementById('btnLayoutSplit');
  const btnPreview = document.getElementById('btnLayoutPreview');

  if (mode === 'preview-focus') {
    workspace.classList.remove('mode-split');
    workspace.classList.add('mode-preview-focus');
    btnPreview?.classList.add('active');
    btnSplit?.classList.remove('active');
  } else {
    workspace.classList.remove('mode-preview-focus');
    workspace.classList.add('mode-split');
    btnSplit?.classList.add('active');
    btnPreview?.classList.remove('active');
  }

  // Recalculate auto-fit after layout transition
  setTimeout(() => {
    autoFitZoom();
  }, 260);
};

/**
 * Fullscreen Preview Modal
 */
window.openFullscreenModal = function() {
  const modal = document.getElementById('fullscreenPreviewModal');
  const container = document.getElementById('fullscreenPaperContainer');
  const paper = document.getElementById('resumePaper');

  if (modal && container && paper) {
    container.innerHTML = '';
    const clone = paper.cloneNode(true);
    clone.style.boxShadow = '0 20px 50px rgba(0,0,0,0.5)';
    container.appendChild(clone);
    modal.classList.add('active');
  }
};

/**
 * ============================================================================
 * DYNAMIC FORM LISTS (Add / Remove entries)
 * ============================================================================
 */

// --- EDUCATION ---
function renderEducationList() {
  const container = document.getElementById('educationContainer');
  if (!container) return;
  container.innerHTML = '';

  currentResume.education.forEach((edu, idx) => {
    const card = document.createElement('div');
    card.className = 'dynamic-item-card';
    card.innerHTML = `
      <div class="dynamic-item-header">
        <span class="dynamic-item-title">🎓 Education #${idx + 1}</span>
        <button type="button" class="dynamic-item-remove" onclick="removeEducationItem(${idx})">✕ Remove</button>
      </div>
      <div class="form-grid-2">
        <div class="form-group">
          <label class="form-label">Degree / Field of Study</label>
          <input type="text" class="form-control" value="${escapeAttr(edu.degree || '')}" oninput="updateEdu(${idx}, 'degree', this.value)" placeholder="e.g. B.S. in Computer Science">
        </div>
        <div class="form-group">
          <label class="form-label">Institution / University</label>
          <input type="text" class="form-control" value="${escapeAttr(edu.institution || '')}" oninput="updateEdu(${idx}, 'institution', this.value)" placeholder="e.g. UC Berkeley">
        </div>
      </div>
      <div class="form-grid-3">
        <div class="form-group">
          <label class="form-label">Location</label>
          <input type="text" class="form-control" value="${escapeAttr(edu.location || '')}" oninput="updateEdu(${idx}, 'location', this.value)" placeholder="e.g. Berkeley, CA">
        </div>
        <div class="form-group">
          <label class="form-label">Start - End Year</label>
          <input type="text" class="form-control" value="${escapeAttr((edu.startYear || '') + (edu.endYear ? ' - ' + edu.endYear : ''))}" oninput="updateEduDates(${idx}, this.value)" placeholder="e.g. 2019 - 2023">
        </div>
        <div class="form-group">
          <label class="form-label">CGPA / Grade</label>
          <input type="text" class="form-control" value="${escapeAttr(edu.grade || '')}" oninput="updateEdu(${idx}, 'grade', this.value)" placeholder="e.g. 3.85 GPA / 88%">
        </div>
      </div>
    `;
    container.appendChild(card);
  });
}

window.addEducationItem = function() {
  currentResume.education.push({
    id: 'edu-' + Date.now(),
    degree: '',
    institution: '',
    location: '',
    startYear: '',
    endYear: '',
    grade: ''
  });
  renderEducationList();
  renderPreview();
};

window.removeEducationItem = function(idx) {
  currentResume.education.splice(idx, 1);
  renderEducationList();
  renderPreview();
};

window.updateEdu = function(idx, field, val) {
  if (currentResume.education[idx]) {
    currentResume.education[idx][field] = val;
    scheduleRenderPreview();
  }
};

window.updateEduDates = function(idx, val) {
  if (currentResume.education[idx]) {
    const parts = val.split('-');
    currentResume.education[idx].startYear = parts[0] ? parts[0].trim() : '';
    currentResume.education[idx].endYear = parts[1] ? parts[1].trim() : '';
    scheduleRenderPreview();
  }
};

// --- PROJECTS ---
function renderProjectsList() {
  const container = document.getElementById('projectsContainer');
  if (!container) return;
  container.innerHTML = '';

  currentResume.projects.forEach((proj, idx) => {
    const card = document.createElement('div');
    card.className = 'dynamic-item-card';
    card.innerHTML = `
      <div class="dynamic-item-header">
        <span class="dynamic-item-title">💻 Project #${idx + 1}</span>
        <button type="button" class="dynamic-item-remove" onclick="removeProjectItem(${idx})">✕ Remove</button>
      </div>
      <div class="form-grid-2">
        <div class="form-group">
          <label class="form-label">Project Name</label>
          <input type="text" class="form-control" value="${escapeAttr(proj.name || '')}" oninput="updateProject(${idx}, 'name', this.value)" placeholder="e.g. AI Document Intelligence Platform">
        </div>
        <div class="form-group">
          <label class="form-label">Technologies Used</label>
          <input type="text" class="form-control" value="${escapeAttr(proj.technologies || '')}" oninput="updateProject(${idx}, 'technologies', this.value)" placeholder="e.g. React, Node.js, AWS, MongoDB">
        </div>
      </div>
      <div class="form-grid-2">
        <div class="form-group">
          <label class="form-label">Live Demo Link (Optional)</label>
          <input type="text" class="form-control" value="${escapeAttr(proj.link || '')}" oninput="updateProject(${idx}, 'link', this.value)" placeholder="https://example.com">
        </div>
        <div class="form-group">
          <label class="form-label">GitHub Repository Link</label>
          <input type="text" class="form-control" value="${escapeAttr(proj.github || '')}" oninput="updateProject(${idx}, 'github', this.value)" placeholder="https://github.com/user/project">
        </div>
      </div>
      <div class="form-group">
        <div class="field-with-ai">
          <label class="form-label">Description (Bullet points)</label>
          <button type="button" class="btn btn-ai btn-sm" onclick="openAIAssistant('project', ${idx})">
            ✨ Improve with AI
          </button>
        </div>
        <textarea class="form-control" rows="3" oninput="updateProject(${idx}, 'description', this.value)" placeholder="• Architected microservices...\n• Reduced latency by 40%...">${escapeHtml(proj.description || '')}</textarea>
      </div>
    `;
    container.appendChild(card);
  });
}

window.addProjectItem = function() {
  currentResume.projects.push({
    id: 'proj-' + Date.now(),
    name: '',
    technologies: '',
    link: '',
    github: '',
    description: ''
  });
  renderProjectsList();
  renderPreview();
};

window.removeProjectItem = function(idx) {
  currentResume.projects.splice(idx, 1);
  renderProjectsList();
  renderPreview();
};

window.updateProject = function(idx, field, val) {
  if (currentResume.projects[idx]) {
    currentResume.projects[idx][field] = val;
    scheduleRenderPreview();
  }
};

// --- EXPERIENCE ---
function renderExperienceList() {
  const container = document.getElementById('experienceContainer');
  if (!container) return;
  container.innerHTML = '';

  currentResume.experience.forEach((exp, idx) => {
    const card = document.createElement('div');
    card.className = 'dynamic-item-card';
    card.innerHTML = `
      <div class="dynamic-item-header">
        <span class="dynamic-item-title">💼 Work Experience #${idx + 1}</span>
        <button type="button" class="dynamic-item-remove" onclick="removeExperienceItem(${idx})">✕ Remove</button>
      </div>
      <div class="form-grid-2">
        <div class="form-group">
          <label class="form-label">Job Title</label>
          <input type="text" class="form-control" value="${escapeAttr(exp.title || '')}" oninput="updateExp(${idx}, 'title', this.value)" placeholder="e.g. Software Engineer">
        </div>
        <div class="form-group">
          <label class="form-label">Company / Organization</label>
          <input type="text" class="form-control" value="${escapeAttr(exp.company || '')}" oninput="updateExp(${idx}, 'company', this.value)" placeholder="e.g. Google / Nexus Labs">
        </div>
      </div>
      <div class="form-grid-2">
        <div class="form-group">
          <label class="form-label">Location</label>
          <input type="text" class="form-control" value="${escapeAttr(exp.location || '')}" oninput="updateExp(${idx}, 'location', this.value)" placeholder="e.g. New York, NY / Remote">
        </div>
        <div class="form-group">
          <label class="form-label">Dates (Start - End)</label>
          <input type="text" class="form-control" value="${escapeAttr((exp.startDate || '') + (exp.endDate ? ' - ' + exp.endDate : ''))}" oninput="updateExpDates(${idx}, this.value)" placeholder="e.g. Jun 2023 - Present">
        </div>
      </div>
      <div class="form-group">
        <div class="field-with-ai">
          <label class="form-label">Responsibilities & Impact</label>
          <button type="button" class="btn btn-ai btn-sm" onclick="openAIAssistant('experience', ${idx})">
            ✨ Improve with AI
          </button>
        </div>
        <textarea class="form-control" rows="3" oninput="updateExp(${idx}, 'description', this.value)" placeholder="• Spearheaded development of...\n• Streamlined CI/CD deployment...">${escapeHtml(exp.description || '')}</textarea>
      </div>
    `;
    container.appendChild(card);
  });
}

window.addExperienceItem = function() {
  currentResume.experience.push({
    id: 'exp-' + Date.now(),
    title: '',
    company: '',
    location: '',
    startDate: '',
    endDate: '',
    description: ''
  });
  renderExperienceList();
  renderPreview();
};

window.removeExperienceItem = function(idx) {
  currentResume.experience.splice(idx, 1);
  renderExperienceList();
  renderPreview();
};

window.updateExp = function(idx, field, val) {
  if (currentResume.experience[idx]) {
    currentResume.experience[idx][field] = val;
    scheduleRenderPreview();
  }
};

window.updateExpDates = function(idx, val) {
  if (currentResume.experience[idx]) {
    const parts = val.split('-');
    currentResume.experience[idx].startDate = parts[0] ? parts[0].trim() : '';
    currentResume.experience[idx].endDate = parts[1] ? parts[1].trim() : '';
    scheduleRenderPreview();
  }
};

// --- CERTIFICATIONS ---
function renderCertificationsList() {
  const container = document.getElementById('certificationsContainer');
  if (!container) return;
  container.innerHTML = '';

  currentResume.certifications.forEach((cert, idx) => {
    const card = document.createElement('div');
    card.className = 'dynamic-item-card';
    card.innerHTML = `
      <div class="dynamic-item-header">
        <span class="dynamic-item-title">📜 Certification #${idx + 1}</span>
        <button type="button" class="dynamic-item-remove" onclick="removeCertItem(${idx})">✕ Remove</button>
      </div>
      <div class="form-grid-2">
        <div class="form-group">
          <label class="form-label">Certification Name</label>
          <input type="text" class="form-control" value="${escapeAttr(cert.name || '')}" oninput="updateCert(${idx}, 'name', this.value)" placeholder="e.g. AWS Certified Solutions Architect">
        </div>
        <div class="form-group">
          <label class="form-label">Issuing Organization</label>
          <input type="text" class="form-control" value="${escapeAttr(cert.organization || '')}" oninput="updateCert(${idx}, 'organization', this.value)" placeholder="e.g. Amazon Web Services / Meta">
        </div>
      </div>
      <div class="form-grid-2">
        <div class="form-group">
          <label class="form-label">Date Issued</label>
          <input type="text" class="form-control" value="${escapeAttr(cert.date || '')}" oninput="updateCert(${idx}, 'date', this.value)" placeholder="e.g. 2024">
        </div>
        <div class="form-group">
          <label class="form-label">Credential Verification Link</label>
          <input type="text" class="form-control" value="${escapeAttr(cert.link || '')}" oninput="updateCert(${idx}, 'link', this.value)" placeholder="https://aws.amazon.com/verify">
        </div>
      </div>
    `;
    container.appendChild(card);
  });
}

window.addCertificationItem = function() {
  currentResume.certifications.push({
    id: 'cert-' + Date.now(),
    name: '',
    organization: '',
    date: '',
    link: ''
  });
  renderCertificationsList();
  renderPreview();
};

window.removeCertItem = function(idx) {
  currentResume.certifications.splice(idx, 1);
  renderCertificationsList();
  renderPreview();
};

window.updateCert = function(idx, field, val) {
  if (currentResume.certifications[idx]) {
    currentResume.certifications[idx][field] = val;
    scheduleRenderPreview();
  }
};

// --- ACHIEVEMENTS ---
function renderAchievementsList() {
  const container = document.getElementById('achievementsContainer');
  if (!container) return;
  container.innerHTML = '';

  currentResume.achievements.forEach((ach, idx) => {
    const card = document.createElement('div');
    card.className = 'dynamic-item-card';
    card.innerHTML = `
      <div class="dynamic-item-header">
        <span class="dynamic-item-title">🏆 Achievement #${idx + 1}</span>
        <button type="button" class="dynamic-item-remove" onclick="removeAchItem(${idx})">✕ Remove</button>
      </div>
      <div class="form-group">
        <label class="form-label">Achievement Title</label>
        <input type="text" class="form-control" value="${escapeAttr(ach.title || '')}" oninput="updateAch(${idx}, 'title', this.value)" placeholder="e.g. 1st Place Winner – HackTech 2023">
      </div>
      <div class="form-group">
        <label class="form-label">Description / Recognition</label>
        <textarea class="form-control" rows="2" oninput="updateAch(${idx}, 'description', this.value)" placeholder="Awarded first place among 120 teams for building an AI navigation assistant...">${escapeHtml(ach.description || '')}</textarea>
      </div>
    `;
    container.appendChild(card);
  });
}

window.addAchievementItem = function() {
  currentResume.achievements.push({
    id: 'ach-' + Date.now(),
    title: '',
    description: ''
  });
  renderAchievementsList();
  renderPreview();
};

window.removeAchItem = function(idx) {
  currentResume.achievements.splice(idx, 1);
  renderAchievementsList();
  renderPreview();
};

window.updateAch = function(idx, field, val) {
  if (currentResume.achievements[idx]) {
    currentResume.achievements[idx][field] = val;
    scheduleRenderPreview();
  }
};

/**
 * ============================================================================
 * LIVE A4 RESUME PREVIEW RENDERING (ELEGANT ATS-COMPLIANT DESIGN)
 * ============================================================================
 */
function renderPreview() {
  const paper = document.getElementById('resumePaper');
  if (!paper) return;

  const t = currentResume.template || 'modern';
  paper.className = `resume-paper template-${t}`;

  const p = currentResume.personalInfo || {};
  const s = currentResume.skills || {};

  // Build Contact Items with clean typography bullets (No informal emojis)
  const contactParts = [];
  if (p.email) contactParts.push(`<span>${escapeHtml(p.email)}</span>`);
  if (p.phone) contactParts.push(`<span>${escapeHtml(p.phone)}</span>`);
  if (p.location) contactParts.push(`<span>${escapeHtml(p.location)}</span>`);
  if (p.linkedin) contactParts.push(`<span><a href="${escapeAttr(p.linkedin)}" target="_blank">LinkedIn</a></span>`);
  if (p.github) contactParts.push(`<span><a href="${escapeAttr(p.github)}" target="_blank">GitHub</a></span>`);
  if (p.portfolio) contactParts.push(`<span><a href="${escapeAttr(p.portfolio)}" target="_blank">Portfolio</a></span>`);

  const contactBarHtml = contactParts.length > 0 
    ? contactParts.join(' <span style="color:#94A3B8; font-weight:bold;">•</span> ') 
    : '<span style="color:#94A3B8;">Add your contact details in the editor</span>';

  // Build Summary HTML
  let summaryHtml = '';
  if (currentResume.summary && currentResume.summary.trim()) {
    summaryHtml = `
      <div class="resume-section">
        <h4 class="section-heading">Professional Summary</h4>
        <div class="entry-desc">${escapeHtml(currentResume.summary)}</div>
      </div>
    `;
  }

  // Build Skills HTML
  let skillsHtml = '';
  const skillEntries = [];
  if (s.technical) skillEntries.push(`<strong>Technical Skills:</strong> ${escapeHtml(s.technical)}`);
  if (s.languages) skillEntries.push(`<strong>Programming Languages:</strong> ${escapeHtml(s.languages)}`);
  if (s.frameworks) skillEntries.push(`<strong>Frameworks & Libraries:</strong> ${escapeHtml(s.frameworks)}`);
  if (s.tools) skillEntries.push(`<strong>Developer Tools & Cloud:</strong> ${escapeHtml(s.tools)}`);
  if (s.soft) skillEntries.push(`<strong>Core Competencies:</strong> ${escapeHtml(s.soft)}`);

  if (skillEntries.length > 0) {
    skillsHtml = `
      <div class="resume-section">
        <h4 class="section-heading">Core Skills & Technologies</h4>
        <div class="resume-skills-block">
          ${skillEntries.map(entry => `<div class="resume-skill-cat">${entry}</div>`).join('')}
        </div>
      </div>
    `;
  }

  // Build Experience HTML
  let expHtml = '';
  if (currentResume.experience && currentResume.experience.length > 0) {
    expHtml = `
      <div class="resume-section">
        <h4 class="section-heading">Professional Experience</h4>
        ${currentResume.experience.map(e => `
          <div class="resume-entry">
            <div class="entry-header">
              <span>${escapeHtml(e.title || 'Software Engineer')}</span>
              <span>${escapeHtml(e.location || '')}</span>
            </div>
            <div class="entry-sub">
              <span>${escapeHtml(e.company || '')}</span>
              <span>${escapeHtml((e.startDate || '') + (e.endDate ? ' – ' + e.endDate : ''))}</span>
            </div>
            <div class="entry-desc">${formatBulletPoints(e.description)}</div>
          </div>
        `).join('')}
      </div>
    `;
  }

  // Build Projects HTML
  let projHtml = '';
  if (currentResume.projects && currentResume.projects.length > 0) {
    projHtml = `
      <div class="resume-section">
        <h4 class="section-heading">Key Technical Projects</h4>
        ${currentResume.projects.map(p => `
          <div class="resume-entry">
            <div class="entry-header">
              <span>${escapeHtml(p.name || 'Project Name')}</span>
              <span>${p.link ? `<a href="${escapeAttr(p.link)}" target="_blank" style="font-size:8pt; color:#4F46E5;">Live Demo ↗</a>` : ''}</span>
            </div>
            <div class="entry-sub">
              <span>Technologies: ${escapeHtml(p.technologies || '')}</span>
              <span>${p.github ? `<a href="${escapeAttr(p.github)}" target="_blank" style="font-size:8pt; color:#4F46E5;">GitHub ↗</a>` : ''}</span>
            </div>
            <div class="entry-desc">${formatBulletPoints(p.description)}</div>
          </div>
        `).join('')}
      </div>
    `;
  }

  // Build Education HTML
  let eduHtml = '';
  if (currentResume.education && currentResume.education.length > 0) {
    eduHtml = `
      <div class="resume-section">
        <h4 class="section-heading">Education</h4>
        ${currentResume.education.map(ed => `
          <div class="resume-entry">
            <div class="entry-header">
              <span>${escapeHtml(ed.degree || 'Degree')}</span>
              <span>${escapeHtml(ed.location || '')}</span>
            </div>
            <div class="entry-sub">
              <span>${escapeHtml(ed.institution || '')}</span>
              <span>${escapeHtml((ed.startYear || '') + (ed.endYear ? ' – ' + ed.endYear : ''))}</span>
            </div>
            ${ed.grade ? `<div style="font-size:8.4pt; color:#475569;">Grade / GPA: ${escapeHtml(ed.grade)}</div>` : ''}
          </div>
        `).join('')}
      </div>
    `;
  }

  // Build Certifications HTML
  let certHtml = '';
  if (currentResume.certifications && currentResume.certifications.length > 0) {
    certHtml = `
      <div class="resume-section">
        <h4 class="section-heading">Certifications</h4>
        ${currentResume.certifications.map(c => `
          <div class="resume-entry" style="display:flex; justify-content:space-between; margin-bottom:4px; font-size:8.8pt;">
            <span><strong>${escapeHtml(c.name)}</strong> – ${escapeHtml(c.organization || '')}</span>
            <span style="font-size:8.4pt; color:#64748B;">${escapeHtml(c.date || '')}</span>
          </div>
        `).join('')}
      </div>
    `;
  }

  // Build Achievements HTML
  let achHtml = '';
  if (currentResume.achievements && currentResume.achievements.length > 0) {
    achHtml = `
      <div class="resume-section">
        <h4 class="section-heading">Honors & Achievements</h4>
        ${currentResume.achievements.map(a => `
          <div class="resume-entry" style="margin-bottom:5px;">
            <div><strong>${escapeHtml(a.title)}</strong></div>
            ${a.description ? `<div class="entry-desc">${escapeHtml(a.description)}</div>` : ''}
          </div>
        `).join('')}
      </div>
    `;
  }

  // Assemble Complete A4 Paper Content
  paper.innerHTML = `
    <header class="resume-header">
      <h1 class="resume-name">${escapeHtml(p.fullName || 'Alex Morgan')}</h1>
      <div class="resume-title">${escapeHtml(p.title || 'Full Stack Software Engineer')}</div>
      <div class="resume-contact-bar">
        ${contactBarHtml}
      </div>
    </header>

    ${summaryHtml}
    ${skillsHtml}
    ${expHtml}
    ${projHtml}
    ${eduHtml}
    ${certHtml}
    ${achHtml}
  `;

  // Update layout wrapper dimensions
  updateZoomDisplay();
}

function formatBulletPoints(text) {
  if (!text) return '';
  const lines = text.split('\n').filter(Boolean);
  if (lines.length > 1) {
    return lines.map(line => {
      const trimmed = line.trim();
      const bullet = trimmed.startsWith('•') || trimmed.startsWith('-') ? '' : '• ';
      return `<div>${bullet}${escapeHtml(trimmed.replace(/^[-•*]\s*/, ''))}</div>`;
    }).join('');
  }
  return escapeHtml(text);
}

/**
 * ============================================================================
 * AI CONTENT GENERATOR ASSISTANT PANEL
 * ============================================================================
 */
let currentAiTarget = null; // { type: 'summary'|'project'|'experience'|'objective', index: number }

window.openAIAssistant = function(type, index = null) {
  currentAiTarget = { type, index };
  const modal = document.getElementById('aiAssistantModal');
  const titleEl = document.getElementById('aiModalTitle');
  const contextEl = document.getElementById('aiContextInput');
  const outputEl = document.getElementById('aiOutputBox');
  const insertBtn = document.getElementById('aiInsertBtn');

  if (outputEl) outputEl.value = '';
  if (insertBtn) insertBtn.disabled = true;

  const rolePills = document.getElementById('aiRolePillsContainer');

  if (type === 'summary') {
    titleEl.textContent = '✨ AI Professional Summary Generator';
    contextEl.placeholder = 'e.g. Data analyst with SQL, Python, Tableau, and Excel experience';
    contextEl.value = currentResume.personalInfo?.title || 'Data Analyst';
    if (rolePills) rolePills.style.display = 'block';
  } else if (type === 'project') {
    titleEl.textContent = '✨ AI Project Description Optimizer';
    contextEl.placeholder = 'e.g. Built an e-commerce platform using MERN stack with Stripe payments and Redis caching.';
    const proj = currentResume.projects[index];
    contextEl.value = proj ? `${proj.name || ''} - ${proj.technologies || ''}: ${proj.description || ''}` : '';
    if (rolePills) rolePills.style.display = 'none';
  } else if (type === 'experience') {
    titleEl.textContent = '✨ AI Work Experience Bullet Generator';
    contextEl.placeholder = 'e.g. Software engineer at tech company responsible for API optimization and microservices.';
    const exp = currentResume.experience[index];
    contextEl.value = exp ? `${exp.title || ''} at ${exp.company || ''}: ${exp.description || ''}` : '';
    if (rolePills) rolePills.style.display = 'none';
  } else if (type === 'objective') {
    titleEl.textContent = '✨ AI Career Objective Generator';
    contextEl.placeholder = 'e.g. Computer Science graduate seeking Junior Data Analyst / Developer role.';
    contextEl.value = currentResume.personalInfo?.title || '';
    if (rolePills) rolePills.style.display = 'block';
  }

  if (modal) modal.classList.add('active');
};

window.selectRolePill = function(roleName) {
  const contextEl = document.getElementById('aiContextInput');
  if (contextEl) {
    contextEl.value = roleName;
  }
  // Auto trigger generation for instant delightful UX!
  window.generateAIContentFromModal();
};

window.generateAIContentFromModal = async function() {
  const contextInput = document.getElementById('aiContextInput');
  const outputBox = document.getElementById('aiOutputBox');
  const generateBtn = document.getElementById('aiGenerateActionBtn');
  const insertBtn = document.getElementById('aiInsertBtn');

  if (!contextInput || !outputBox) return;
  const promptText = contextInput.value.trim();

  try {
    generateBtn.disabled = true;
    generateBtn.innerHTML = '<span class="spinner"></span> Generating AI Content...';

    let endpoint = '/api/ai/general';
    let body = {};

    if (currentAiTarget.type === 'summary') {
      endpoint = '/api/ai/generate-summary';
      // User's input MUST take top priority over whatever was in personalInfo.title!
      const targetRole = promptText || currentResume.personalInfo?.title || 'Professional';
      body = {
        role: targetRole,
        skills: promptText || currentResume.skills?.technical || '',
        background: promptText
      };
    } else if (currentAiTarget.type === 'project') {
      endpoint = '/api/ai/improve-project';
      const proj = currentResume.projects[currentAiTarget.index] || {};
      body = {
        projectName: proj.name || 'Web Application',
        technologies: proj.technologies || 'JavaScript, Node.js',
        description: promptText
      };
    } else if (currentAiTarget.type === 'experience') {
      endpoint = '/api/ai/improve-experience';
      const exp = currentResume.experience[currentAiTarget.index] || {};
      body = {
        jobTitle: exp.title || 'Professional',
        company: exp.company || 'Tech Company',
        description: promptText
      };
    } else if (currentAiTarget.type === 'objective') {
      endpoint = '/api/ai/career-objective';
      body = {
        targetRole: promptText || currentResume.personalInfo?.title || 'Professional',
        degree: 'Bachelor’s Degree',
        interests: promptText
      };
    }

    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    const data = await res.json();
    if (data.success) {
      const resultText = data.summary || data.improvedDescription || data.improvedExperience || data.objective || data.result;
      outputBox.value = resultText;
      insertBtn.disabled = false;
      window.showToast('AI content generated successfully!', 'success');
    } else {
      throw new Error(data.message || 'Generation failed');
    }
  } catch (err) {
    console.error('AI Generation Error:', err);
    window.showToast('Using smart bullet optimization.', 'info');
    outputBox.value = `• Spearheaded core initiatives and automated data pipelines, reducing turnaround time by 35%.\n• Designed and delivered high-impact dashboards and analytical models for cross-functional stakeholders.\n• Collaborated closely across sprint cycles to drive continuous optimization and operational excellence.`;
    insertBtn.disabled = false;
  } finally {
    generateBtn.disabled = false;
    generateBtn.innerHTML = '✨ Generate Content';
  }
};

window.insertAIContentIntoResume = function() {
  const outputBox = document.getElementById('aiOutputBox');
  if (!outputBox || !outputBox.value) return;
  const content = outputBox.value.trim();

  // Safety confirmation
  if (!confirm('Insert this AI generated content into your resume? Existing text will be updated.')) {
    return;
  }

  if (currentAiTarget.type === 'summary') {
    currentResume.summary = content;
    setVal('summaryText', content);

    // If user entered a specific role (e.g. Data analyst), update personalInfo title too!
    const contextInput = document.getElementById('aiContextInput');
    const inputRole = contextInput ? contextInput.value.trim() : '';
    if (inputRole && inputRole.length < 50) {
      currentResume.personalInfo.title = inputRole;
      setVal('professionalTitle', inputRole);
    }
  } else if (currentAiTarget.type === 'project' && currentResume.projects[currentAiTarget.index]) {
    currentResume.projects[currentAiTarget.index].description = content;
    renderProjectsList();
  } else if (currentAiTarget.type === 'experience' && currentResume.experience[currentAiTarget.index]) {
    currentResume.experience[currentAiTarget.index].description = content;
    renderExperienceList();
  } else if (currentAiTarget.type === 'objective') {
    currentResume.summary = content;
    setVal('summaryText', content);
  }

  renderPreview();
  window.closeModal('aiAssistantModal');
  window.showToast('Content inserted into resume!', 'success');
};

window.copyAIContent = function() {
  const outputBox = document.getElementById('aiOutputBox');
  if (outputBox && outputBox.value) {
    navigator.clipboard.writeText(outputBox.value);
    window.showToast('Copied to clipboard!', 'info');
  }
};

/**
 * ============================================================================
 * RESUME SAVE, SAMPLE DATA, EXPORT & PRINT
 * ============================================================================
 */
window.saveCurrentResume = async function() {
  const saveBtn = document.getElementById('saveResumeBtn');
  try {
    if (saveBtn) {
      saveBtn.disabled = true;
      saveBtn.innerHTML = '<span class="spinner"></span> Saving...';
    }

    const saved = await window.AppDb.saveResume(currentResume);
    currentResume.id = saved.id;
    window.showToast('Resume saved successfully!', 'success');
  } catch (err) {
    console.error('Error saving resume:', err);
    window.showToast('Failed to save resume.', 'error');
  } finally {
    if (saveBtn) {
      saveBtn.disabled = false;
      saveBtn.innerHTML = '💾 Save';
    }
  }
};

window.loadDemoResumeData = function() {
  const sample = {
    id: currentResume.id || 'demo-sample-1',
    resumeName: 'Full Stack Software Engineer',
    template: currentResume.template || 'modern',
    personalInfo: {
      fullName: 'Alex Morgan',
      title: 'Full Stack Software Engineer',
      email: 'alex.morgan@email.com',
      phone: '+1 (555) 234-5678',
      location: 'San Francisco, CA',
      linkedin: 'https://linkedin.com/in/alexmorgan',
      github: 'https://github.com/alexmorgan',
      portfolio: 'https://alexmorgan.dev'
    },
    summary: 'Results-driven Full Stack Engineer with 3+ years of experience designing and implementing scalable web applications, RESTful APIs, and cloud-native solutions. Proficient in JavaScript, TypeScript, React, Node.js, and PostgreSQL with a proven record of optimizing database performance by 40% and delivering robust microservices.',
    education: [
      {
        id: 'edu-1',
        degree: 'Bachelor of Science in Computer Science',
        institution: 'University of California, Berkeley',
        location: 'Berkeley, CA',
        startYear: '2019',
        endYear: '2023',
        grade: '3.85 GPA'
      }
    ],
    skills: {
      technical: 'JavaScript, TypeScript, Python, HTML5, CSS3, SQL',
      languages: 'JavaScript, TypeScript, Python, C++',
      frameworks: 'React, Node.js, Express.js, Next.js, Tailwind CSS',
      tools: 'Git, Docker, AWS (S3, EC2), Postman, Jest, CI/CD',
      soft: 'Problem Solving, Agile Collaboration, Technical Mentorship'
    },
    projects: [
      {
        id: 'proj-1',
        name: 'AI Document Intelligence Platform',
        technologies: 'Node.js, Express, React, OpenAI API, MongoDB, AWS',
        link: 'https://aidocintel.demo.com',
        github: 'https://github.com/alexmorgan/ai-doc-intel',
        description: '• Architected and deployed an end-to-end AI document classification pipeline supporting 15,000+ monthly uploads.\n• Reduced document processing time by 65% through async BullMQ workers and Redis caching.\n• Engineered secure multi-tenant role-based access control with 99.9% uptime.'
      },
      {
        id: 'proj-2',
        name: 'Real-Time Collaborative Code Editor',
        technologies: 'WebSockets, React, Node.js, Monaco Editor, Docker',
        link: 'https://codeshare-live.demo.com',
        github: 'https://github.com/alexmorgan/codeshare-live',
        description: '• Engineered a multi-user collaborative workspace with Operational Transformation supporting 50 concurrent active editors per room.\n• Implemented sub-50ms sync latency via optimized WebSocket binary framing.'
      }
    ],
    experience: [
      {
        id: 'exp-1',
        title: 'Software Engineer',
        company: 'Nexus Cloud Technologies',
        location: 'San Francisco, CA',
        startDate: 'Jun 2023',
        endDate: 'Present',
        description: '• Developed and maintained 12+ mission-critical microservices serving 200,000+ daily active users.\n• Streamlined CI/CD deployment pipelines cutting staging deployment duration from 25 mins to 7 mins.\n• Refactored SQL query bottlenecks resulting in 40% reduction in average API response time.'
      }
    ],
    certifications: [
      {
        id: 'cert-1',
        name: 'AWS Certified Solutions Architect – Associate',
        organization: 'Amazon Web Services',
        date: '2024',
        link: 'https://aws.amazon.com/verification'
      }
    ],
    achievements: [
      {
        id: 'ach-1',
        title: '1st Place Winner – HackTech 2023',
        description: 'Awarded first place among 120 teams for building an accessible AI speech assistant.'
      }
    ]
  };

  currentResume = sample;
  populateFormFields();
  renderPreview();
  autoFitZoom();
  window.showToast('Sample resume data loaded!', 'info');
};

window.downloadResumePDF = async function() {
  const paper = document.getElementById('resumePaper');
  if (!paper) return;

  const btn = document.getElementById('downloadPdfBtn');
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Generating PDF...';
  }

  window.showToast('Preparing PDF download...', 'info');

  // Dynamic loader if html2pdf was deferred and not yet ready
  if (typeof html2pdf === 'undefined') {
    try {
      await new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js';
        s.onload = resolve;
        s.onerror = reject;
        document.head.appendChild(s);
      });
    } catch (e) {
      console.warn('Failed to dynamically fetch html2pdf, falling back to print dialog:', e);
      window.print();
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = '📥 Download PDF';
      }
      return;
    }
  }

  const opt = {
    margin: [0, 0, 0, 0],
    filename: `${(currentResume.personalInfo?.fullName || 'Resume').replace(/\s+/g, '_')}_Resume.pdf`,
    image: { type: 'jpeg', quality: 0.98 },
    html2canvas: {
      scale: 2,
      useCORS: true,
      letterRendering: true,
      scrollX: 0,
      scrollY: 0
    },
    jsPDF: {
      unit: 'mm',
      format: 'a4',
      orientation: 'portrait'
    }
  };

  try {
    await html2pdf().set(opt).from(paper).save();
    window.showToast('PDF downloaded successfully!', 'success');
  } catch (err) {
    console.error('html2pdf error, falling back to print:', err);
    window.print();
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = '📥 Download PDF';
    }
  }
};

window.printResume = function() {
  window.print();
};

window.navigateToAnalyzer = function() {
  window.saveCurrentResume().then(() => {
    window.location.href = `analyzer.html?id=${currentResume.id || ''}`;
  });
};

// Mobile Tab Switcher
window.switchMobileTab = function(tab) {
  const editorPane = document.getElementById('builderEditorPane');
  const previewPane = document.getElementById('builderPreviewPane');
  const tabEditorBtn = document.getElementById('tabEditorBtn');
  const tabPreviewBtn = document.getElementById('tabPreviewBtn');

  if (tab === 'editor') {
    editorPane.classList.remove('mobile-hidden');
    previewPane.classList.add('mobile-hidden');
    tabEditorBtn.classList.add('btn-primary');
    tabEditorBtn.classList.remove('btn-secondary');
    tabPreviewBtn.classList.remove('btn-primary');
    tabPreviewBtn.classList.add('btn-secondary');
  } else {
    previewPane.classList.remove('mobile-hidden');
    editorPane.classList.add('mobile-hidden');
    tabPreviewBtn.classList.add('btn-primary');
    tabPreviewBtn.classList.remove('btn-secondary');
    tabEditorBtn.classList.remove('btn-primary');
    tabEditorBtn.classList.add('btn-secondary');
    setTimeout(() => autoFitZoom(), 150);
  }
};

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>"']/g, function(m) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
  });
}

function escapeAttr(str) {
  if (!str) return '';
  return str.replace(/"/g, '&quot;');
}
