// js/app-config.js
/**
 * ResumeAI application configuration.
 *
 * Authentication is powered by Firebase Authentication.
 * Enable Email/Password and Google providers in Firebase Console.
 */

window.AppAuth = {};
window.AppDb = {};

(function initFirebaseAuth() {
  if (!window.firebase) {
    console.error('Firebase SDK was not loaded.');
    return;
  }

  const config = window.FIREBASE_CONFIG || {};
  const missing = ['apiKey', 'authDomain', 'projectId', 'appId']
    .filter(key => !config[key] || String(config[key]).startsWith('YOUR_'));

  if (missing.length) {
    console.warn(
      'Firebase is not configured. Update js/firebase-config.js with your Firebase Web App config.'
    );
  }

  let firebaseApp;
  let auth;
  try {
    firebaseApp = firebase.apps.length ? firebase.app() : firebase.initializeApp(config);
    auth = firebase.auth();
  } catch (error) {
    console.error('Firebase initialization failed:', error);
  }

  let cachedUser = null;
  try {
    cachedUser = JSON.parse(localStorage.getItem('resumeai_current_user') || 'null');
  } catch (_) {}

  const authListeners = [];
  let resolveReady;
  const ready = new Promise(resolve => { resolveReady = resolve; });

  function serializeUser(user) {
    if (!user) return null;
    return {
      uid: user.uid,
      email: user.email,
      displayName: user.displayName || (user.email ? user.email.split('@')[0] : 'User'),
      photoURL: user.photoURL || '',
      emailVerified: !!user.emailVerified,
      phoneNumber: user.phoneNumber || null,
      providerId: user.providerData?.[0]?.providerId || 'password'
    };
  }

  function mapFirebaseError(error) {
    const code = error?.code || '';
    const messages = {
      'auth/invalid-credential': 'Invalid email or password.',
      'auth/invalid-login-credentials': 'Invalid email or password.',
      'auth/user-not-found': 'No account exists with this email.',
      'auth/wrong-password': 'Invalid email or password.',
      'auth/email-already-in-use': 'An account with this email already exists.',
      'auth/weak-password': 'Password must be at least 6 characters long.',
      'auth/invalid-email': 'Please enter a valid email address.',
      'auth/popup-closed-by-user': 'Google sign-in was cancelled.',
      'auth/popup-blocked': 'Your browser blocked the sign-in popup. Allow popups and try again.',
      'auth/operation-not-allowed': 'This sign-in method is not enabled in Firebase Authentication.',
      'auth/unauthorized-domain': 'This website domain is not authorized in Firebase Authentication.',
      'auth/network-request-failed': 'Network error. Check your internet connection and try again.'
    };
    return new Error(messages[code] || error?.message || 'Authentication failed. Please try again.');
  }

  // Global logout handler used by the sidebar Logout links.
  // It signs out from Firebase, clears the local cached session, and returns
  // the user to the login page.
  window.handleLogout = async function handleLogout() {
    try {
      await window.AppAuth.signOut();
      localStorage.removeItem('resumeai_current_user');
      window.location.replace('/login.html');
    } catch (error) {
      console.error('Logout failed:', error);
      if (window.showToast) {
        window.showToast('Logout failed. Please try again.', 'error');
      } else {
        alert('Logout failed. Please try again.');
      }
    }
  };

  window.AppAuth = {
    ready,

    getCurrentUser: () => {
      if (auth?.currentUser) return serializeUser(auth.currentUser);
      return cachedUser;
    },

    onAuthStateChanged: (callback) => {
      authListeners.push(callback);
      if (auth) {
        return auth.onAuthStateChanged(user => callback(serializeUser(user)));
      }
      setTimeout(() => callback(cachedUser), 0);
      return () => {
        const index = authListeners.indexOf(callback);
        if (index >= 0) authListeners.splice(index, 1);
      };
    },

    signIn: async (email, password) => {
      if (!auth) throw new Error('Firebase is not configured. Update js/firebase-config.js first.');
      try {
        const result = await auth.signInWithEmailAndPassword(email.trim(), password);
        return { user: serializeUser(result.user) };
      } catch (error) {
        throw mapFirebaseError(error);
      }
    },

    signUp: async (email, password, name) => {
      if (!auth) throw new Error('Firebase is not configured. Update js/firebase-config.js first.');
      try {
        const result = await auth.createUserWithEmailAndPassword(email.trim(), password);
        if (name) {
          await result.user.updateProfile({ displayName: name.trim() });
        }
        await result.user.reload();
        return { user: serializeUser(auth.currentUser) };
      } catch (error) {
        throw mapFirebaseError(error);
      }
    },

    signInWithGoogle: async () => {
      if (!auth) throw new Error('Firebase is not configured. Update js/firebase-config.js first.');
      try {
        const provider = new firebase.auth.GoogleAuthProvider();
        provider.setCustomParameters({ prompt: 'select_account' });
        const result = await auth.signInWithPopup(provider);
        return { user: serializeUser(result.user) };
      } catch (error) {
        throw mapFirebaseError(error);
      }
    },

    resetPassword: async (email) => {
      if (!auth) throw new Error('Firebase is not configured. Update js/firebase-config.js first.');
      try {
        await auth.sendPasswordResetEmail(email.trim());
      } catch (error) {
        throw mapFirebaseError(error);
      }
    },

    getIdToken: async (forceRefresh = false) => {
      if (!auth?.currentUser) return null;
      return auth.currentUser.getIdToken(forceRefresh);
    },

    signOut: async () => {
      if (!auth) return true;
      await auth.signOut();
      return true;
    }
  };

  if (auth) {
    auth.onAuthStateChanged(user => {
      cachedUser = serializeUser(user);
      if (cachedUser) {
        localStorage.setItem('resumeai_current_user', JSON.stringify(cachedUser));
      } else {
        localStorage.removeItem('resumeai_current_user');
      }
      authListeners.forEach(fn => {
        try { fn(cachedUser); } catch (e) { console.error(e); }
      });
      resolveReady(cachedUser);
    });
  } else {
    resolveReady(cachedUser);
  }
})();

// Resume data service: Express backend + localStorage fallback.
window.AppDb = {
  getResumes: async (userId) => {
    const effectiveUserId = userId || window.AppAuth.getCurrentUser()?.uid || 'demo-user';
    try {
      const res = await fetch(`/api/resume?userId=${encodeURIComponent(effectiveUserId)}`);
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.resumes) {
          localStorage.setItem('resumeai_saved_resumes', JSON.stringify(data.resumes));
          return data.resumes;
        }
      }
    } catch (e) {
      console.warn('Backend fetch failed, using local storage resumes:', e);
    }

    const local = localStorage.getItem('resumeai_saved_resumes');
    return local ? JSON.parse(local) : [];
  },

  saveResume: async (resumeData) => {
    const now = new Date().toISOString();
    const user = window.AppAuth.getCurrentUser();
    const resume = {
      ...resumeData,
      userId: resumeData.userId || user?.uid || 'demo-user',
      id: resumeData.id || 'res-' + Date.now(),
      updatedAt: now,
      createdAt: resumeData.createdAt || now
    };

    try {
      const token = await window.AppAuth.getIdToken();
      await fetch('/api/resume', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify(resume)
      });
    } catch (e) {
      console.warn('Backend save failed, saved locally:', e);
    }

    const current = JSON.parse(localStorage.getItem('resumeai_saved_resumes') || '[]');
    const idx = current.findIndex(r => r.id === resume.id);
    if (idx >= 0) current[idx] = resume;
    else current.unshift(resume);
    localStorage.setItem('resumeai_saved_resumes', JSON.stringify(current));
    return resume;
  },

  deleteResume: async (id) => {
    try {
      const token = await window.AppAuth.getIdToken();
      await fetch(`/api/resume/${id}`, {
        method: 'DELETE',
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
    } catch (e) {
      console.warn('Backend delete failed, removed locally:', e);
    }

    const current = JSON.parse(localStorage.getItem('resumeai_saved_resumes') || '[]');
    localStorage.setItem(
      'resumeai_saved_resumes',
      JSON.stringify(current.filter(r => r.id !== id))
    );
    return true;
  },

  getResumeById: async (id) => {
    try {
      const res = await fetch(`/api/resume/${id}`);
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.resume) return data.resume;
      }
    } catch (e) {
      console.warn('Backend get failed, checking local:', e);
    }

    const current = JSON.parse(localStorage.getItem('resumeai_saved_resumes') || '[]');
    return current.find(r => r.id === id) || null;
  }
};

window.showToast = function(message, type = 'info') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  let icon = 'ℹ️';
  if (type === 'success') icon = '✓';
  if (type === 'error') icon = '✕';
  if (type === 'warning') icon = '⚠';

  toast.innerHTML = `<span style="font-weight:bold; font-size:1.1rem">${icon}</span> <span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(15px)';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
};
