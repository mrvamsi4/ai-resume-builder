// js/analyzer.js

let selectedResume = null;
let uploadedFile = null;
let savedResumesList = [];

document.addEventListener('DOMContentLoaded', async () => {
  const user = await window.AppAuth.ready;
  if (!user) {
    window.location.href = 'login.html';
    return;
  }

  // Load saved resumes into selector
  await populateResumeSelector();

  // Setup tabs & dropzone
  setupSourceTabs();
  setupDropzone();

  // Check URL params for specific resume ID
  const urlParams = new URLSearchParams(window.location.search);
  const resumeId = urlParams.get('id');
  if (resumeId) {
    const sel = document.getElementById('resumeSelectDropdown');
    if (sel) {
      sel.value = resumeId;
      handleResumeSelection(resumeId);
    }
  } else if (savedResumesList.length > 0) {
    // Default to first resume
    handleResumeSelection(savedResumesList[0].id);
  }
});

async function populateResumeSelector() {
  const select = document.getElementById('resumeSelectDropdown');
  if (!select) return;

  try {
    savedResumesList = await window.AppDb.getResumes();
    select.innerHTML = '';

    if (savedResumesList.length === 0) {
      select.innerHTML = '<option value="">No saved resumes found. Create one first!</option>';
      return;
    }

    savedResumesList.forEach(r => {
      const opt = document.createElement('option');
      opt.value = r.id;
      opt.textContent = `${r.resumeName || 'Untitled'} (${r.personalInfo?.fullName || 'User'})`;
      select.appendChild(opt);
    });

    select.addEventListener('change', (e) => {
      handleResumeSelection(e.target.value);
    });
  } catch (err) {
    console.error('Error fetching resumes:', err);
  }
}

async function handleResumeSelection(resumeId) {
  if (!resumeId) return;
  selectedResume = savedResumesList.find(r => r.id === resumeId) || await window.AppDb.getResumeById(resumeId);
  if (selectedResume) {
    // Automatically trigger initial analysis for smooth UX
    runATSAnalysis();
  }
}

function setupSourceTabs() {
  const btnSaved = document.getElementById('tabSourceSaved');
  const btnUpload = document.getElementById('tabSourceUpload');
  const paneSaved = document.getElementById('paneSourceSaved');
  const paneUpload = document.getElementById('paneSourceUpload');

  if (btnSaved && btnUpload) {
    btnSaved.addEventListener('click', () => {
      btnSaved.classList.add('active');
      btnUpload.classList.remove('active');
      paneSaved.style.display = 'block';
      paneUpload.style.display = 'none';
      uploadedFile = null;
    });

    btnUpload.addEventListener('click', () => {
      btnUpload.classList.add('active');
      btnSaved.classList.remove('active');
      paneUpload.style.display = 'block';
      paneSaved.style.display = 'none';
    });
  }
}

function setupDropzone() {
  const dropzone = document.getElementById('uploadDropzone');
  const fileInput = document.getElementById('resumeFileInput');
  const fileStatus = document.getElementById('fileSelectedBadge');

  if (!dropzone || !fileInput) return;

  dropzone.addEventListener('click', () => fileInput.click());

  dropzone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropzone.classList.add('dragover');
  });

  dropzone.addEventListener('dragleave', () => {
    dropzone.classList.remove('dragover');
  });

  dropzone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropzone.classList.remove('dragover');
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelected(e.dataTransfer.files[0]);
    }
  });

  fileInput.addEventListener('change', (e) => {
    if (e.target.files && e.target.files[0]) {
      handleFileSelected(e.target.files[0]);
    }
  });

  function handleFileSelected(file) {
    if (!file.name.toLowerCase().endsWith('.pdf') && !file.name.toLowerCase().endsWith('.txt')) {
      window.showToast('Please upload a PDF or TXT resume file.', 'warning');
      return;
    }
    uploadedFile = file;
    if (fileStatus) {
      fileStatus.style.display = 'inline-flex';
      fileStatus.innerHTML = `📄 ${escapeHtml(file.name)} (${(file.size / 1024).toFixed(1)} KB)`;
    }
    window.showToast(`Selected: ${file.name}`, 'info');
  }
}

/**
 * Run Comprehensive ATS Analysis
 */
window.runATSAnalysis = async function() {
  const analyzeBtn = document.getElementById('runAnalysisBtn');
  const jobDescText = document.getElementById('jobDescriptionInput')?.value || '';

  try {
    if (analyzeBtn) {
      analyzeBtn.disabled = true;
      analyzeBtn.innerHTML = '<span class="spinner"></span> Analyzing ATS Compatibility...';
    }

    let analysisResult = null;

    if (uploadedFile) {
      // PDF Upload endpoint
      const formData = new FormData();
      formData.append('resumeFile', uploadedFile);
      if (jobDescText) formData.append('jobDescription', jobDescText);

      const res = await fetch('/api/ats/upload-and-analyze', {
        method: 'POST',
        body: formData
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.message);
      analysisResult = data.analysis;
      selectedResume = data.parsedResume;
    } else {
      // Structured resume analysis
      if (!selectedResume) {
        throw new Error('Please select a resume or upload a file first.');
      }

      const res = await fetch('/api/ats/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          resume: selectedResume,
          jobDescription: jobDescText
        })
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.message);
      analysisResult = data.analysis;
    }

    renderAnalysisResults(analysisResult);
    window.showToast('ATS Analysis completed!', 'success');
  } catch (err) {
    console.error('Analysis error:', err);
    window.showToast(err.message || 'ATS Analysis failed.', 'error');
  } finally {
    if (analyzeBtn) {
      analyzeBtn.disabled = false;
      analyzeBtn.innerHTML = '⚡ Re-Analyze Resume';
    }
  }
};

/**
 * Render Scores, Circular Gauge, Bars, and Checklists
 */
function renderAnalysisResults(analysis) {
  const resultsContainer = document.getElementById('atsResultsSection');
  if (resultsContainer) resultsContainer.style.display = 'block';

  // 1. Animate Circular Score
  animateScoreGauge(analysis.score);

  // Status Badge
  const statusBadge = document.getElementById('atsStatusBadge');
  if (statusBadge) {
    statusBadge.textContent = analysis.statusText || 'Your resume is ATS compatible.';
    statusBadge.className = `ats-score-badge-status ${analysis.score >= 80 ? 'badge-success' : (analysis.score >= 65 ? 'badge-warning' : 'badge-danger')}`;
  }

  // 2. Category Progress Bars
  const cats = analysis.categories || {};
  setProgressBar('catKeyword', cats.keywordMatch, '#4F46E5');
  setProgressBar('catSkills', cats.skillsMatch, '#10B981');
  setProgressBar('catStructure', cats.sectionCompleteness, '#0284C7');
  setProgressBar('catFormatting', cats.formatting, '#F59E0B');
  setProgressBar('catReadability', cats.readability, '#8B5CF6');

  const jdRow = document.getElementById('catJobMatchRow');
  if (cats.jobMatch !== null && jdRow) {
    jdRow.style.display = 'flex';
    setProgressBar('catJobMatch', cats.jobMatch, '#EC4899');
  } else if (jdRow) {
    jdRow.style.display = 'none';
  }

  // 3. Strengths Checklist
  const strengthsList = document.getElementById('strengthsList');
  if (strengthsList) {
    strengthsList.innerHTML = (analysis.strengths || []).map(s => `
      <li class="checklist-item">
        <span class="check-icon-success">✓</span>
        <span>${escapeHtml(s)}</span>
      </li>
    `).join('') || '<li class="checklist-item">No specific strengths identified.</li>';
  }

  // 4. Improvements & Suggestions
  const suggestionsList = document.getElementById('suggestionsList');
  if (suggestionsList) {
    suggestionsList.innerHTML = (analysis.suggestions || []).map(s => `
      <li class="checklist-item">
        <span class="check-icon-warning">⚠</span>
        <span>${escapeHtml(s)}</span>
      </li>
    `).join('') || '<li class="checklist-item">Your resume satisfies all primary ATS guidelines!</li>';
  }

  // Scroll smoothly to results
  resultsContainer?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function animateScoreGauge(targetScore) {
  const circle = document.getElementById('gaugeCircleProgress');
  const scoreText = document.getElementById('gaugeScoreText');
  if (!circle || !scoreText) return;

  const circumference = 2 * Math.PI * 45; // r = 45 => ~282.7
  const offset = circumference - (targetScore / 100) * circumference;

  circle.style.strokeDasharray = `${circumference} ${circumference}`;
  circle.style.strokeDashoffset = offset;

  // Determine stroke color
  if (targetScore >= 80) circle.style.stroke = 'var(--success)';
  else if (targetScore >= 65) circle.style.stroke = 'var(--warning)';
  else circle.style.stroke = 'var(--danger)';

  // Count up animation
  let current = 0;
  const step = Math.ceil(targetScore / 30) || 1;
  const interval = setInterval(() => {
    current += step;
    if (current >= targetScore) {
      current = targetScore;
      clearInterval(interval);
    }
    scoreText.textContent = `${current}/100`;
  }, 25);
}

function setProgressBar(prefix, val, color) {
  const fill = document.getElementById(`${prefix}Fill`);
  const text = document.getElementById(`${prefix}Text`);
  const safeVal = Math.max(0, Math.min(100, val || 0));

  if (fill) {
    fill.style.width = `${safeVal}%`;
    if (color) fill.style.backgroundColor = color;
  }
  if (text) {
    text.textContent = `${safeVal}%`;
  }
}

/**
 * ============================================================================
 * JOB DESCRIPTION MATCHING
 * ============================================================================
 */
window.analyzeJobMatch = async function() {
  const title = document.getElementById('jobTitleInput')?.value.trim() || '';
  const company = document.getElementById('jobCompanyInput')?.value.trim() || '';
  const desc = document.getElementById('jobDescriptionInput')?.value.trim() || '';
  const btn = document.getElementById('analyzeJobBtn');

  if (!desc) {
    window.showToast('Please enter a job description to analyze alignment.', 'warning');
    return;
  }

  if (!selectedResume) {
    window.showToast('Please select or upload a resume first.', 'warning');
    return;
  }

  try {
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span> Analyzing Match...';
    }

    const res = await fetch('/api/job/match', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        resume: selectedResume,
        jobTitle: title,
        company: company,
        jobDescription: desc
      })
    });

    const data = await res.json();
    if (!data.success) throw new Error(data.message);

    renderJobMatchResults(data);
    window.showToast(`Job Match Score: ${data.matchPercentage}%`, 'info');
  } catch (err) {
    console.error('Job match error:', err);
    window.showToast(err.message || 'Job match analysis failed.', 'error');
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = '🔍 Analyze Match';
    }
  }
};

function renderJobMatchResults(data) {
  const container = document.getElementById('jobResultsContainer');
  if (!container) return;
  container.style.display = 'block';

  // Percentage badge
  const pctEl = document.getElementById('jobMatchPercentage');
  if (pctEl) pctEl.textContent = `${data.matchPercentage}% Match`;

  // Matching Skills
  const matchGroup = document.getElementById('matchingSkillsPills');
  if (matchGroup) {
    matchGroup.innerHTML = (data.matchingSkills || []).map(s => `
      <span class="skill-pill skill-pill-match">✓ ${escapeHtml(s)}</span>
    `).join('') || '<span style="font-size:0.85rem; color:var(--text-muted);">None detected</span>';
  }

  // Missing Skills
  const missingGroup = document.getElementById('missingSkillsPills');
  if (missingGroup) {
    missingGroup.innerHTML = (data.missingSkills || []).map(s => `
      <span class="skill-pill skill-pill-missing">✕ ${escapeHtml(s)}</span>
    `).join('') || '<span class="badge badge-success">No critical skills missing!</span>';
  }

  // Recommended Keywords
  const kwGroup = document.getElementById('recommendedKeywordsPills');
  if (kwGroup) {
    kwGroup.innerHTML = (data.recommendedKeywords || []).map(s => `
      <span class="skill-pill skill-pill-keyword">💡 ${escapeHtml(s)}</span>
    `).join('') || '<span style="font-size:0.85rem; color:var(--text-muted);">Keyword density optimal</span>';
  }

  // Also re-run overall ATS calculation to incorporate Job Match into the main score!
  window.runATSAnalysis();
}

window.openBuilderFromAnalyzer = function() {
  if (selectedResume && selectedResume.id) {
    window.location.href = `builder.html?id=${selectedResume.id}`;
  } else {
    window.location.href = 'builder.html';
  }
};

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>"']/g, function(m) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
  });
}
