// js/dashboard.js

document.addEventListener('DOMContentLoaded', async () => {
  const currentUser = await window.AppAuth.ready;
  if (!currentUser) {
    window.location.href = 'login.html';
    return;
  }

  // Populate user profile in sidebar/topbar
  updateUserUI(currentUser);

  // Load and render resumes
  await loadDashboardData();

  // Bind event listeners
  setupDashboardEvents();
});

function updateUserUI(user) {
  const nameEls = document.querySelectorAll('.user-name, #welcomeUserName');
  const emailEls = document.querySelectorAll('.user-email');
  const avatarEls = document.querySelectorAll('.user-avatar');

  const displayName = user.displayName || user.name || 'Alex Morgan';
  const email = user.email || 'alex.morgan@email.com';
  const initial = displayName.charAt(0).toUpperCase();

  nameEls.forEach(el => el.textContent = displayName);
  emailEls.forEach(el => el.textContent = email);
  avatarEls.forEach(el => {
    if (user.photoURL) {
      el.innerHTML = `<img src="${user.photoURL}" alt="${displayName}" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">`;
    } else {
      el.textContent = initial;
    }
  });

  // Set today's date
  const dateEl = document.getElementById('currentDateText');
  if (dateEl) {
    const options = { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' };
    dateEl.textContent = new Date().toLocaleDateString('en-US', options);
  }
}

async function loadDashboardData() {
  const resumesGrid = document.getElementById('resumesGrid');
  const emptyState = document.getElementById('emptyState');
  if (!resumesGrid) return;

  try {
    const resumes = await window.AppDb.getResumes();
    renderStats(resumes);

    if (!resumes || resumes.length === 0) {
      resumesGrid.innerHTML = '';
      if (emptyState) emptyState.style.display = 'block';
      return;
    }

    if (emptyState) emptyState.style.display = 'none';
    resumesGrid.innerHTML = '';

    resumes.forEach(resume => {
      const card = createResumeCard(resume);
      resumesGrid.appendChild(card);
    });
  } catch (err) {
    console.error('Failed to load dashboard resumes:', err);
    window.showToast('Failed to load resumes. Refreshing...', 'error');
  }
}

function renderStats(resumes) {
  const totalCountEl = document.getElementById('totalResumesCount');
  const avgScoreEl = document.getElementById('avgAtsScore');
  const bestScoreEl = document.getElementById('bestAtsScore');
  const completionEl = document.getElementById('avgCompletionRate');

  const count = resumes.length;
  if (totalCountEl) totalCountEl.textContent = count;

  if (count === 0) {
    if (avgScoreEl) avgScoreEl.textContent = '0%';
    if (bestScoreEl) bestScoreEl.textContent = '0/100';
    if (completionEl) completionEl.textContent = '0%';
    return;
  }

  let totalScore = 0;
  let bestScore = 0;
  resumes.forEach(r => {
    const score = Number(r.atsScore || 75);
    totalScore += score;
    if (score > bestScore) bestScore = score;
  });

  const avg = Math.round(totalScore / count);
  if (avgScoreEl) avgScoreEl.textContent = `${avg}%`;
  if (bestScoreEl) bestScoreEl.textContent = `${bestScore}/100`;
  if (completionEl) completionEl.textContent = `94%`;
}

function createResumeCard(resume) {
  const card = document.createElement('div');
  card.className = 'resume-card';
  card.id = `card-${resume.id}`;

  const score = resume.atsScore || 80;
  let scoreClass = 'score-high';
  if (score < 65) scoreClass = 'score-low';
  else if (score < 78) scoreClass = 'score-med';

  const updatedDate = resume.updatedAt
    ? new Date(resume.updatedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    : 'Recently';

  const templateName = resume.template
    ? resume.template.charAt(0).toUpperCase() + resume.template.slice(1)
    : 'Modern';

  card.innerHTML = `
    <div>
      <div class="resume-card-header">
        <div class="resume-card-title">
          <h3>${escapeHtml(resume.resumeName || 'Untitled Resume')}</h3>
          <span class="resume-card-date">Updated ${updatedDate} • Template: ${templateName}</span>
        </div>
        <span class="badge badge-primary">${templateName}</span>
      </div>

      <div class="resume-card-stats">
        <div>
          <span style="font-size:0.75rem; color:var(--text-muted); display:block;">ATS SCORE</span>
          <div class="ats-score-pill ${scoreClass}">
            <span>🎯</span> ${score} / 100
          </div>
        </div>
        <div>
          <span style="font-size:0.75rem; color:var(--text-muted); display:block;">STATUS</span>
          <span style="font-size:0.85rem; font-weight:600; color:var(--text-main);">ATS Ready</span>
        </div>
      </div>

      <div class="completion-bar-wrapper">
        <div class="completion-label">
          <span>Completeness</span>
          <span>95%</span>
        </div>
        <div class="progress-bar-bg">
          <div class="progress-bar-fill" style="width: 95%;"></div>
        </div>
      </div>
    </div>

    <div class="resume-card-actions">
      <a href="builder.html?id=${resume.id}" class="btn btn-secondary btn-sm" title="Edit Resume">
        ✏️ Edit
      </a>
      <a href="analyzer.html?id=${resume.id}" class="btn btn-secondary btn-sm" title="Analyze ATS">
        🎯 Analyze
      </a>
      <a href="builder.html?id=${resume.id}&preview=true" class="btn btn-primary btn-sm" style="grid-column: span 2;" title="Live Preview & PDF">
        📄 Preview & PDF
      </a>
      <button class="btn btn-delete btn-sm" onclick="confirmDeleteResume('${resume.id}', '${escapeHtml(resume.resumeName || 'this resume')}')">
        🗑️ Delete
      </button>
    </div>
  `;

  return card;
}

function setupDashboardEvents() {
  // Mobile sidebar toggle
  const mobileToggle = document.getElementById('mobileMenuToggle');
  const sidebar = document.querySelector('.sidebar');
  if (mobileToggle && sidebar) {
    mobileToggle.addEventListener('click', () => {
      sidebar.classList.toggle('open');
    });
  }

  // Create New Resume Modal / Prompt
  const createBtn = document.getElementById('createNewResumeBtn');
  if (createBtn) {
    createBtn.addEventListener('click', () => {
      openCreateResumeModal();
    });
  }

  // Search input filter
  const searchInput = document.getElementById('searchResumes');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      const q = e.target.value.toLowerCase();
      document.querySelectorAll('.resume-card').forEach(card => {
        const text = card.textContent.toLowerCase();
        card.style.display = text.includes(q) ? 'flex' : 'none';
      });
    });
  }
}

function openCreateResumeModal() {
  const modal = document.getElementById('newResumeModal');
  if (modal) {
    modal.classList.add('active');
  } else {
    // Direct prompt fallback
    const name = prompt('Enter a name for your new resume:', 'Software Engineer Resume');
    if (name) {
      window.location.href = `builder.html?new=true&name=${encodeURIComponent(name)}`;
    }
  }
}

window.closeModal = function(id) {
  const modal = document.getElementById(id);
  if (modal) modal.classList.remove('active');
};

window.handleCreateResumeSubmit = function(e) {
  if (e) e.preventDefault();
  const nameInput = document.getElementById('newResumeName');
  const templateSelect = document.getElementById('newResumeTemplate');
  const name = nameInput ? nameInput.value.trim() : 'My Professional Resume';
  const template = templateSelect ? templateSelect.value : 'modern';

  window.location.href = `builder.html?new=true&name=${encodeURIComponent(name)}&template=${template}`;
};

window.confirmDeleteResume = async function(id, name) {
  if (confirm(`Are you sure you want to delete "${name}"? This action cannot be undone.`)) {
    try {
      await window.AppDb.deleteResume(id);
      window.showToast('Resume deleted successfully.', 'info');
      await loadDashboardData();
    } catch (err) {
      window.showToast('Failed to delete resume.', 'error');
    }
  }
};

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>"']/g, function(m) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
  });
}
