// js/auth.js
document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');
  const googleLoginBtn = document.getElementById('googleLoginBtn');
  const googleRegisterBtn = document.getElementById('googleRegisterBtn');
  const forgotPasswordLink = document.getElementById('forgotPasswordLink');
  const authErrorAlert = document.getElementById('authErrorAlert');

  function showError(msg) {
    if (authErrorAlert) {
      authErrorAlert.textContent = msg;
      authErrorAlert.style.display = 'block';
    } else {
      window.showToast?.(msg, 'error') || alert(msg);
    }
  }
  function hideError() {
    if (authErrorAlert) authErrorAlert.style.display = 'none';
  }
  async function redirectAfterAuth(message = 'Authentication successful!') {
    window.showToast?.(message, 'success');
    await window.AppAuth.ready;
    window.location.assign('/dashboard.html');
  }
  async function runGoogleSignIn(button) {
    hideError();
    if (button) {
      button.disabled = true;
      button.innerHTML = '<span class="spinner"></span> Connecting to Google...';
    }
    try {
      await window.AppAuth.signInWithGoogle();
      await redirectAfterAuth('Google sign-in successful!');
    } catch (err) {
      console.error('Google sign-in error:', err);
      showError(err.message || 'Google sign-in failed.');
      if (button) {
        button.disabled = false;
        button.innerHTML = 'Continue with Google';
      }
    }
  }

  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      hideError();
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;
      const submitBtn = loginForm.querySelector('button[type="submit"]');
      if (!email || !password) return showError('Please enter both email and password.');
      try {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner"></span> Logging in...';
        await window.AppAuth.signIn(email, password);
        await redirectAfterAuth('Login successful!');
      } catch (err) {
        console.error('Login error:', err);
        showError(err.message || 'Invalid email or password.');
        submitBtn.disabled = false;
        submitBtn.innerHTML = 'Login';
      }
    });
  }

  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      hideError();
      const fullName = document.getElementById('fullName').value.trim();
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;
      const confirmPassword = document.getElementById('confirmPassword').value;
      const submitBtn = registerForm.querySelector('button[type="submit"]');
      if (!fullName || !email || !password) return showError('Please fill in all required fields.');
      if (password.length < 6) return showError('Password must be at least 6 characters long.');
      if (password !== confirmPassword) return showError('Passwords do not match. Please verify.');
      try {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner"></span> Creating Account...';
        await window.AppAuth.signUp(email, password, fullName);
        await redirectAfterAuth('Account created successfully!');
      } catch (err) {
        console.error('Registration error:', err);
        showError(err.message || 'Failed to create account.');
        submitBtn.disabled = false;
        submitBtn.innerHTML = 'Create Account';
      }
    });
  }

  if (googleLoginBtn) googleLoginBtn.addEventListener('click', () => runGoogleSignIn(googleLoginBtn));
  if (googleRegisterBtn) googleRegisterBtn.addEventListener('click', () => runGoogleSignIn(googleRegisterBtn));

  if (forgotPasswordLink) {
    forgotPasswordLink.addEventListener('click', async (e) => {
      e.preventDefault();
      hideError();
      const email = document.getElementById('email')?.value.trim();
      if (!email) return showError('Enter your email address first, then click Forgot Password.');
      try {
        await window.AppAuth.resetPassword(email);
        window.showToast?.('Password reset email sent. Check your inbox.', 'success');
      } catch (err) {
        showError(err.message || 'Unable to send password reset email.');
      }
    });
  }

  document.querySelectorAll('.password-toggle').forEach(toggleBtn => {
    toggleBtn.addEventListener('click', () => {
      const input = toggleBtn.parentElement.querySelector('input');
      if (!input) return;
      const isPassword = input.type === 'password';
      input.type = isPassword ? 'text' : 'password';
      toggleBtn.textContent = isPassword ? 'Hide' : 'Show';
    });
  });
});
