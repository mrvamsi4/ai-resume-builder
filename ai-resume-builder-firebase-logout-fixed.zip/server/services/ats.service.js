// server/services/ats.service.js

// Comprehensive database of technical, domain, and soft skills
const INDUSTRY_SKILLS_DB = [
  // Programming Languages
  'javascript', 'typescript', 'python', 'java', 'c++', 'c#', 'c', 'go', 'golang', 'rust', 'php', 'ruby', 'swift', 'kotlin', 'sql', 'r', 'dart', 'html', 'html5', 'css', 'css3', 'sass', 'scss',
  // Frontend
  'react', 'react.js', 'vue', 'vue.js', 'angular', 'next.js', 'nuxt.js', 'svelte', 'tailwind', 'tailwind css', 'bootstrap', 'material ui', 'redux', 'mobx', 'zustand', 'webpack', 'vite', 'graphql',
  // Backend & Cloud
  'node.js', 'express', 'express.js', 'nest.js', 'django', 'flask', 'fastapi', 'spring boot', 'laravel', 'asp.net', 'ruby on rails', 'rest api', 'restful api', 'microservices', 'websocket', 'grpc',
  'aws', 'amazon web services', 'azure', 'gcp', 'google cloud', 'docker', 'kubernetes', 'terraform', 'ci/cd', 'github actions', 'jenkins', 'linux', 'serverless', 'lambda', 's3', 'ec2',
  // Databases
  'mongodb', 'postgresql', 'postgres', 'mysql', 'sqlite', 'redis', 'firebase', 'firestore', 'dynamodb', 'cassandra', 'elasticsearch', 'prisma', 'sequelize', 'mongoose',
  // Data, AI & ML
  'machine learning', 'deep learning', 'artificial intelligence', 'pandas', 'numpy', 'scikit-learn', 'tensorflow', 'pytorch', 'nlp', 'computer vision', 'data analysis', 'power bi', 'tableau', 'spark',
  // Methodologies & Tools
  'git', 'github', 'gitlab', 'postman', 'jest', 'mocha', 'cypress', 'selenium', 'agile', 'scrum', 'jira', 'figma', 'unit testing', 'integration testing', 'system design',
  // Soft Skills
  'leadership', 'communication', 'problem solving', 'teamwork', 'collaboration', 'critical thinking', 'time management', 'adaptability', 'mentorship', 'stakeholder management'
];

// Strong action verbs for resumes
const ACTION_VERBS = [
  'architected', 'spearheaded', 'engineered', 'developed', 'designed', 'implemented', 'optimized',
  'streamlined', 'orchestrated', 'built', 'deployed', 'formulated', 'led', 'managed', 'created',
  'delivered', 'reduced', 'increased', 'maximized', 'accelerated', 'transformed', 'automated',
  'resolved', 'collaborated', 'authored', 'established', 'integrated', 'refactored', 'mentored'
];

/**
 * Clean and tokenize text
 */
function tokenize(text) {
  if (!text) return [];
  return text
    .toLowerCase()
    .replace(/[^a-z0-9+#.\s]/g, ' ')
    .split(/\s+/)
    .filter(w => w.length > 1);
}

/**
 * Analyze a structured resume object
 */
function analyzeStructuredResume(resume, jobDesc = null) {
  const pInfo = resume.personalInfo || {};
  const summary = resume.summary || '';
  const edu = Array.isArray(resume.education) ? resume.education : [];
  const skillsObj = resume.skills || {};
  const projects = Array.isArray(resume.projects) ? resume.projects : [];
  const experience = Array.isArray(resume.experience) ? resume.experience : [];
  const certs = Array.isArray(resume.certifications) ? resume.certifications : [];
  const achievements = Array.isArray(resume.achievements) ? resume.achievements : [];

  // Combine full text
  const skillsText = typeof skillsObj === 'string'
    ? skillsObj
    : Object.values(skillsObj).filter(Boolean).join(' ');

  const projectsText = projects.map(p => `${p.name || ''} ${p.technologies || ''} ${p.description || ''}`).join(' ');
  const expText = experience.map(e => `${e.title || ''} ${e.company || ''} ${e.description || ''}`).join(' ');
  const certsText = certs.map(c => `${c.name || ''} ${c.organization || ''}`).join(' ');
  const achText = achievements.map(a => `${a.title || ''} ${a.description || ''}`).join(' ');

  const fullResumeText = [
    pInfo.fullName,
    pInfo.title,
    summary,
    skillsText,
    projectsText,
    expText,
    certsText,
    achText
  ].join(' ').toLowerCase();

  const words = tokenize(fullResumeText);
  const wordCount = words.length;

  const strengths = [];
  const warnings = [];
  const suggestions = [];

  // 1. SECTION COMPLETENESS (15% weight)
  let sectionPoints = 0;
  const totalSections = 7;

  // Personal info
  if (pInfo.fullName && (pInfo.email || pInfo.phone)) {
    sectionPoints += 1;
    strengths.push('Complete contact information with email and phone');
  } else {
    warnings.push('Incomplete contact details');
    suggestions.push('Ensure your full name, professional email, and phone number are visible.');
  }

  // Summary
  if (summary && summary.trim().length >= 60) {
    sectionPoints += 1;
    strengths.push('Professional summary included');
  } else {
    warnings.push('Brief or missing professional summary');
    suggestions.push('Add an impactful 3-4 sentence professional summary highlighting your core expertise.');
  }

  // Education
  if (edu.length > 0 && edu[0].degree && edu[0].institution) {
    sectionPoints += 1;
    strengths.push('Valid education section with institution and degree');
  } else {
    warnings.push('Education details missing');
    suggestions.push('Include your degree, institution name, and graduation year.');
  }

  // Skills
  if (skillsText.trim().length > 20) {
    sectionPoints += 1;
    strengths.push('Comprehensive technical & soft skills section');
  } else {
    warnings.push('Skills section is too brief');
    suggestions.push('Add categorized technical skills, frameworks, and domain competencies.');
  }

  // Projects
  if (projects.length >= 1) {
    sectionPoints += 1;
    strengths.push(`Showcases ${projects.length} relevant project(s)`);
  } else {
    warnings.push('No projects listed');
    suggestions.push('Add at least 2 relevant projects highlighting modern tech stacks and impact.');
  }

  // Experience / Internships
  if (experience.length >= 1) {
    sectionPoints += 1;
    strengths.push(`Includes professional work experience (${experience.length} position(s))`);
  } else {
    // For students, maybe they don't have experience yet
    warnings.push('No work experience or internships listed');
    suggestions.push('If you lack formal experience, add academic projects, freelance work, or club leadership.');
  }

  // Certifications / Achievements
  if (certs.length > 0 || achievements.length > 0) {
    sectionPoints += 1;
    strengths.push('Certifications / Honors / Achievements section present');
  } else {
    suggestions.push('Include industry certifications (AWS, Google, Meta) or academic achievements to stand out.');
  }

  const sectionScore = Math.min(100, Math.round((sectionPoints / totalSections) * 100));

  // 2. SKILLS MATCH (20% weight)
  const foundSkills = [];
  INDUSTRY_SKILLS_DB.forEach(skill => {
    // Check if skill exists as whole word or token
    const regex = new RegExp(`\\b${skill.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
    if (regex.test(fullResumeText)) {
      foundSkills.push(skill);
    }
  });

  let skillScore = 0;
  if (foundSkills.length >= 12) {
    skillScore = 95;
    strengths.push(`Strong technical skill depth (${foundSkills.length} identified ATS skills)`);
  } else if (foundSkills.length >= 8) {
    skillScore = 82;
    strengths.push(`Good variety of technical skills (${foundSkills.length} skills found)`);
  } else if (foundSkills.length >= 5) {
    skillScore = 65;
    warnings.push('Moderate skill variety');
    suggestions.push('Include more specific technologies, frameworks, and tools in your skills section.');
  } else {
    skillScore = 45;
    warnings.push('Low ATS technical skill count');
    suggestions.push('Expand your skills section with specific languages, databases, cloud tools, and libraries.');
  }

  // 3. FORMATTING & STRUCTURE (15% weight)
  let formattingScore = 80;
  // Check action verbs
  let actionVerbCount = 0;
  ACTION_VERBS.forEach(verb => {
    if (fullResumeText.includes(verb)) actionVerbCount++;
  });

  if (actionVerbCount >= 6) {
    formattingScore += 15;
    strengths.push(`Excellent use of dynamic action verbs (${actionVerbCount}+ verbs found)`);
  } else if (actionVerbCount >= 3) {
    formattingScore += 8;
  } else {
    formattingScore -= 10;
    warnings.push('Weak action verbs in descriptions');
    suggestions.push('Start bullet points with strong power verbs like Architected, Spearheaded, Engineered, Optimized.');
  }

  // Check metrics/numbers (e.g., 40%, $10k, 5,000, 3x)
  const metricMatches = fullResumeText.match(/\d+[%kKxX+]|\d+\s*(users|clients|requests|ms|seconds|minutes|hours|days|percent)/g);
  if (metricMatches && metricMatches.length >= 3) {
    formattingScore += 5;
    strengths.push('Well-quantified achievements with concrete numerical metrics');
  } else {
    warnings.push('Few quantified results or metrics');
    suggestions.push('Add measurable achievements (e.g., "Reduced latency by 40%", "Served 10,000+ users").');
  }
  formattingScore = Math.max(30, Math.min(100, formattingScore));

  // 4. READABILITY & LENGTH (10% weight)
  let readabilityScore = 85;
  if (wordCount >= 250 && wordCount <= 750) {
    readabilityScore = 95;
    strengths.push(`Optimal resume length (${wordCount} words - ideal 1-page density)`);
  } else if (wordCount < 250) {
    readabilityScore = 60;
    warnings.push('Resume is too brief');
    suggestions.push('Expand project descriptions and summary to reach at least 300 words.');
  } else {
    readabilityScore = 75;
    warnings.push('Resume is quite lengthy');
    suggestions.push('Aim for concise, focused bullet points to keep your resume easily scannable on 1 page.');
  }

  // 5. KEYWORD MATCH & JOB MATCH (30% + 10% or 40% if no JD)
  let keywordScore = 80;
  let jobMatchScore = null;
  let matchingSkills = [];
  let missingSkills = [];
  let recommendedKeywords = [];

  if (jobDesc && jobDesc.trim().length > 20) {
    const jdWords = tokenize(jobDesc);
    const jdSkills = [];

    INDUSTRY_SKILLS_DB.forEach(skill => {
      const regex = new RegExp(`\\b${skill.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
      if (regex.test(jobDesc.toLowerCase())) {
        jdSkills.push(skill);
      }
    });

    // Check intersection
    matchingSkills = jdSkills.filter(s => foundSkills.includes(s));
    missingSkills = jdSkills.filter(s => !foundSkills.includes(s));

    if (jdSkills.length > 0) {
      const ratio = matchingSkills.length / jdSkills.length;
      jobMatchScore = Math.round(ratio * 100);
      keywordScore = Math.round(ratio * 80 + 20);

      if (jobMatchScore >= 75) {
        strengths.push(`High target job description alignment (${jobMatchScore}% match)`);
      } else if (jobMatchScore >= 50) {
        warnings.push(`Moderate job match (${jobMatchScore}%). Several target skills are missing.`);
      } else {
        warnings.push(`Low job match (${jobMatchScore}%). Important keywords from the job posting are absent.`);
      }

      if (missingSkills.length > 0) {
        recommendedKeywords = missingSkills.slice(0, 8);
        suggestions.push(`Integrate missing job posting skills: ${missingSkills.slice(0, 5).join(', ')}.`);
      }
    } else {
      jobMatchScore = 78;
      keywordScore = 82;
      recommendedKeywords = ['REST APIs', 'Cloud Computing', 'Git Workflow', 'CI/CD Pipelines', 'Performance Optimization'];
    }
  } else {
    // General keyword analysis based on detected role
    keywordScore = Math.min(95, Math.round(50 + (foundSkills.length * 3.5)));
    recommendedKeywords = ['RESTful Architecture', 'Unit Testing', 'CI/CD', 'Docker', 'Agile/Scrum', 'Cloud Deployment'];
    if (foundSkills.length < 8) {
      suggestions.push('Add more industry-standard technical keywords relevant to your target engineering track.');
    }
  }

  // CALCULATE WEIGHTED TOTAL
  let totalScore = 0;
  if (jobMatchScore !== null) {
    totalScore = Math.round(
      (keywordScore * 0.30) +
      (skillScore * 0.20) +
      (sectionScore * 0.15) +
      (formattingScore * 0.15) +
      (readabilityScore * 0.10) +
      (jobMatchScore * 0.10)
    );
  } else {
    totalScore = Math.round(
      (keywordScore * 0.30) +
      (skillScore * 0.25) +
      (sectionScore * 0.20) +
      (formattingScore * 0.15) +
      (readabilityScore * 0.10)
    );
  }

  totalScore = Math.max(35, Math.min(98, totalScore));

  let statusText = 'Your resume is ATS compatible.';
  let statusBadge = 'success';
  if (totalScore < 60) {
    statusText = 'Needs significant optimization before submitting to ATS.';
    statusBadge = 'danger';
  } else if (totalScore < 75) {
    statusText = 'Moderate ATS compatibility. Applying recommendations will boost interview callbacks.';
    statusBadge = 'warning';
  } else if (totalScore >= 85) {
    statusText = 'Excellent ATS compatibility! Your resume is well-structured and keyword-optimized.';
    statusBadge = 'excellent';
  }

  return {
    score: totalScore,
    statusText,
    statusBadge,
    categories: {
      keywordMatch: keywordScore,
      skillsMatch: skillScore,
      sectionCompleteness: sectionScore,
      formatting: formattingScore,
      readability: readabilityScore,
      jobMatch: jobMatchScore
    },
    metrics: {
      wordCount,
      foundSkillsCount: foundSkills.length,
      actionVerbsCount: actionVerbCount
    },
    foundSkills: foundSkills.slice(0, 16),
    matchingSkills,
    missingSkills,
    recommendedKeywords,
    strengths,
    warnings,
    suggestions: suggestions.slice(0, 6)
  };
}

/**
 * Parse raw resume text (e.g. from uploaded PDF) into structured resume fields
 */
function parseRawResumeText(rawText) {
  const text = rawText || '';
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  
  // Extract email
  const emailMatch = text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
  const email = emailMatch ? emailMatch[0] : '';

  // Extract phone
  const phoneMatch = text.match(/(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/);
  const phone = phoneMatch ? phoneMatch[0] : '';

  // Extract links
  const linkedinMatch = text.match(/linkedin\.com\/in\/[a-zA-Z0-9_-]+/i);
  const githubMatch = text.match(/github\.com\/[a-zA-Z0-9_-]+/i);

  // Guess name from first non-empty line
  const fullName = lines.length > 0 && lines[0].length < 40 ? lines[0] : 'Applicant';

  // Build basic resume representation
  return {
    personalInfo: {
      fullName,
      email,
      phone,
      linkedin: linkedinMatch ? `https://${linkedinMatch[0]}` : '',
      github: githubMatch ? `https://${githubMatch[0]}` : ''
    },
    summary: text.slice(0, 300),
    education: [{ degree: 'Degree from uploaded resume', institution: 'University / College' }],
    skills: text, // whole text will be searched for skills
    projects: [{ name: 'Project from Resume', description: text.slice(200, 600) }],
    experience: [{ title: 'Professional Experience', company: 'Previous Company', description: text.slice(400, 800) }]
  };
}

module.exports = {
  analyzeStructuredResume,
  parseRawResumeText,
  INDUSTRY_SKILLS_DB,
  ACTION_VERBS
};
