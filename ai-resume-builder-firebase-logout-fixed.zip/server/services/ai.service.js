// server/services/ai.service.js
require('dotenv').config();

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

/**
 * Call Gemini REST API
 */
async function callGemini(prompt, systemInstruction = '') {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`;
  
  const payload = {
    contents: [
      {
        parts: [
          { text: systemInstruction ? `${systemInstruction}\n\nTask:\n${prompt}` : prompt }
        ]
      }
    ],
    generationConfig: {
      temperature: 0.7,
      maxOutputTokens: 800
    }
  };

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Gemini API Error: ${response.status} - ${errorText}`);
  }

  const data = await response.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error('No content returned by Gemini API');
  return text.trim();
}

/**
 * Call OpenAI REST API
 */
async function callOpenAI(prompt, systemInstruction = '') {
  const url = 'https://api.openai.com/v1/chat/completions';
  
  const messages = [];
  if (systemInstruction) {
    messages.push({ role: 'system', content: systemInstruction });
  }
  messages.push({ role: 'user', content: prompt });

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages,
      temperature: 0.7,
      max_tokens: 800
    })
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`OpenAI API Error: ${response.status} - ${errorText}`);
  }

  const data = await response.json();
  const text = data?.choices?.[0]?.message?.content;
  if (!text) throw new Error('No content returned by OpenAI API');
  return text.trim();
}

/**
 * Unified AI Caller with Smart Fallback
 */
async function generateAIContent(prompt, systemInstruction = '', fallbackGenerator = null) {
  // 1. Try Gemini if key is provided
  if (GEMINI_API_KEY && GEMINI_API_KEY !== 'your_gemini_api_key_here' && GEMINI_API_KEY.length > 10) {
    try {
      return await callGemini(prompt, systemInstruction);
    } catch (err) {
      console.warn('Gemini API call failed, attempting fallback...', err.message);
    }
  }

  // 2. Try OpenAI if key is provided
  if (OPENAI_API_KEY && OPENAI_API_KEY !== 'your_openai_api_key_here' && OPENAI_API_KEY.length > 10) {
    try {
      return await callOpenAI(prompt, systemInstruction);
    } catch (err) {
      console.warn('OpenAI API call failed, attempting fallback...', err.message);
    }
  }

  // 3. Smart Domain-Aware Heuristic Resume Engine Fallback
  if (fallbackGenerator) {
    return fallbackGenerator();
  }

  return "Results-driven professional with a proven track record of driving operational efficiency, optimizing core processes, and delivering scalable solutions in collaborative environments.";
}

/**
 * Professional Summary Generator with Role-Specific Domain Intelligence
 */
async function generateSummary({ role, experienceYears, skills, background, tone = 'professional' }) {
  // Normalize role input
  const inputRole = (role || background || 'Professional').trim();
  const normalized = inputRole.toLowerCase();
  const exp = experienceYears ? `${experienceYears}+ years of experience` : 'proven hands-on experience';

  const systemInstruction = `You are an elite executive resume writer and career coach specializing in ATS-optimized resumes. Write a punchy, 3-4 sentence professional summary highlighting impact, tech stack, and key metrics tailored strictly for the candidate's exact target role: "${inputRole}". Do not confuse this with software engineering unless explicitly requested. Do not include introductory conversational filler or quotes.`;
  
  const prompt = `Write a high-converting, ATS-friendly professional resume summary for:
- Exact Target Role: ${inputRole}
- Experience Level: ${exp}
- Relevant Skills / Context: ${skills || background || inputRole}
- Tone: ${tone}

Ensure it includes strong action verbs, quantifiable metrics, and industry-standard keywords appropriate for this specific discipline.`;

  // Domain-Aware Heuristic Generator for all industry roles
  const fallback = () => {
    // 1. Data Analyst / Business Intelligence / Data Analytics
    if (normalized.includes('data anal') || normalized.includes('bi ') || normalized.includes('business intell') || normalized.includes('analytics') || normalized.includes('tableau') || normalized.includes('power bi')) {
      return `Analytical and detail-oriented Data Analyst with ${exp} transforming complex datasets into actionable business intelligence. Highly proficient in SQL, Python, Excel (Advanced Modeling), Tableau, and Power BI with a proven record of designing automated ETL reporting pipelines that improved decision-making speed by 35% and identified $250K+ in operational cost savings. Adept at statistical data mining, A/B testing analysis, and translating executive stakeholder requirements into high-impact interactive dashboards.`;
    }

    // 2. Data Scientist / Machine Learning / AI
    if (normalized.includes('data sci') || normalized.includes('machine learn') || normalized.includes('ml ') || normalized.includes('ai ') || normalized.includes('artificial')) {
      return `Results-oriented Data Scientist & Machine Learning Engineer with ${exp} developing predictive models and scalable AI algorithms. Proficient in Python, R, TensorFlow, PyTorch, Scikit-Learn, and SQL, with expertise spanning natural language processing, computer vision, and end-to-end MLOps pipelines. Track record of engineering predictive scoring models that boosted forecasting accuracy by 28% and deploying automated production models serving 500,000+ real-time inferences daily.`;
    }

    // 3. Frontend Developer / UI Engineer
    if (normalized.includes('frontend') || normalized.includes('front-end') || normalized.includes('front end') || normalized.includes('react') || normalized.includes('vue') || normalized.includes('angular') || normalized.includes('ui dev')) {
      return `Passionate and performance-focused Frontend Developer with ${exp} building accessible, high-traffic web applications with modern design systems. Highly skilled in JavaScript (ES6+), TypeScript, React.js, Next.js, HTML5, and Tailwind CSS. Proven track record of optimizing Core Web Vitals to achieve 95+ Google Lighthouse performance scores, cutting initial page load times by 45%, and collaborating with UX teams to elevate user engagement metrics.`;
    }

    // 4. Backend Developer / API Engineer
    if (normalized.includes('backend') || normalized.includes('back-end') || normalized.includes('back end') || normalized.includes('api dev') || normalized.includes('node') || normalized.includes('java ') || normalized.includes('golang') || normalized.includes('django')) {
      return `Performance-driven Backend Developer with ${exp} architecting scalable distributed microservices, RESTful and GraphQL APIs, and high-concurrency database systems. Expert in Node.js, Python, Java, PostgreSQL, Redis, and Docker. Successfully reduced API endpoint latency by 40% under peak loads of 100,000+ daily active users while maintaining 99.98% service uptime and rigorous security standards.`;
    }

    // 5. DevOps / Cloud Engineer / SRE
    if (normalized.includes('devops') || normalized.includes('cloud') || normalized.includes('sre') || normalized.includes('reliability') || normalized.includes('aws') || normalized.includes('kubernetes') || normalized.includes('infrastructure')) {
      return `Solutions-driven DevOps & Cloud Infrastructure Engineer with ${exp} designing automated CI/CD deployment pipelines, container orchestration, and Infrastructure-as-Code (IaC). Proficient in AWS, Docker, Kubernetes, Terraform, GitHub Actions, and Linux administration. Reduced deployment lead times by 65%, eliminated production deployment failures by 80%, and achieved 99.99% multi-region cloud infrastructure availability.`;
    }

    // 6. Cybersecurity Analyst / Security Engineer
    if (normalized.includes('cyber') || normalized.includes('security') || normalized.includes('infosec') || normalized.includes('soc ') || normalized.includes('penetration')) {
      return `Vigilant Cybersecurity Analyst with ${exp} conducting threat intelligence assessments, vulnerability scanning, and incident response operations. Proficient in SIEM monitoring (Splunk), network penetration testing (Wireshark, Metasploit), firewall configuration, and compliance frameworks (SOC 2, ISO 27001). Successfully mitigated 50+ critical vulnerability exposures and hardened corporate networks to zero security breaches.`;
    }

    // 7. UI/UX Designer / Product Designer
    if (normalized.includes('ui') || normalized.includes('ux') || normalized.includes('design') || normalized.includes('product design') || normalized.includes('figma')) {
      return `User-centric UI/UX and Product Designer with ${exp} crafting intuitive, accessible, and high-converting web and mobile interfaces. Expert in Figma, design systems, rapid prototyping, wireframing, and user research methodologies. Collaborated cross-functionally with engineering and product stakeholders to revamp core user journeys, driving a 32% increase in customer onboarding conversion and earning a 4.8/5 user satisfaction score.`;
    }

    // 8. Product Manager / Project Manager / Scrum Master
    if (normalized.includes('product man') || normalized.includes('project man') || normalized.includes('scrum') || normalized.includes('agile') || normalized.includes('pm')) {
      return `Strategic and outcome-focused Product Manager with ${exp} driving multi-million-dollar digital products from discovery through go-to-market execution. Expert in Agile/Scrum methodologies, user story mapping, competitive analysis, and data-driven prioritization. Spearheaded cross-functional squads of 14+ engineers and designers to launch core revenue-generating features, increasing quarterly active users by 38% and user retention by 24%.`;
    }

    // 9. Business Analyst
    if (normalized.includes('business anal') || normalized.includes('requirements') || normalized.includes('process anal')) {
      return `Analytical Business Analyst with ${exp} bridging the gap between strategic business objectives and technical delivery teams. Skilled in requirements elicitation, workflow mapping (BPMN), gap analysis, and agile backlog management. Engineered re-aligned business processes that decreased manual data reconciliation turnaround by 45% while ensuring 100% adherence to project milestone timelines and client compliance mandates.`;
    }

    // 10. QA Engineer / Test Automation
    if (normalized.includes('qa') || normalized.includes('test') || normalized.includes('quality') || normalized.includes('automation')) {
      return `Quality Assurance Engineer with ${exp} architecting robust automated testing frameworks and rigorous manual validation strategies. Proficient in Selenium, Cypress, Playwright, Jest, Postman, and CI/CD test integration. Spearheaded end-to-end regression automation suites that cut manual testing cycles by 70% and captured 99.4% of pre-release defects prior to production rollout.`;
    }

    // 11. Digital Marketing / SEO / Content Specialist
    if (normalized.includes('market') || normalized.includes('seo') || normalized.includes('content') || normalized.includes('growth') || normalized.includes('social media')) {
      return `Data-driven Digital Marketing Specialist with ${exp} managing high-ROI multi-channel campaigns, SEO strategies, and conversion rate optimization (CRO). Proficient in Google Analytics 4, SEMrush, Google Ads, Meta Ads Manager, and email marketing automation. Scaled organic web traffic by 140% year-over-year while reducing customer acquisition costs (CAC) by 25% across competitive market sectors.`;
    }

    // 12. Finance / Accounting / Banking
    if (normalized.includes('finance') || normalized.includes('account') || normalized.includes('audit') || normalized.includes('banking') || normalized.includes('financial')) {
      return `Detail-oriented Financial Analyst with ${exp} building complex financial models, variance analyses, budgeting, and corporate forecasts. Expert in Advanced Excel, ERP systems (SAP, NetSuite), financial statement analysis, and GAAP compliance standards. Streamlined quarterly close processes to reduce reporting turnaround by 3 days while delivering financial models supporting $5M+ in strategic capital allocations.`;
    }

    // 13. Human Resources / Talent Acquisition / Recruiter
    if (normalized.includes('hr') || normalized.includes('human res') || normalized.includes('talent') || normalized.includes('recruit') || normalized.includes('people ops')) {
      return `Dynamic Human Resources and Talent Acquisition Specialist with ${exp} managing full-cycle recruitment, employee relations, onboarding programs, and retention initiatives. Partnered with department heads to source, interview, and onboard 80+ top-tier candidates annually while reducing average time-to-hire by 30% and boosting new hire 90-day retention to 94%.`;
    }

    // 14. Student / Fresher / Entry Level / Graduate
    if (normalized.includes('student') || normalized.includes('fresher') || normalized.includes('graduate') || normalized.includes('intern') || normalized.includes('entry level') || normalized.includes('entry-level')) {
      return `High-achieving and motivated ${inputRole} graduate with a strong academic foundation, hands-on capstone project experience, and modern technical acumen. Highly disciplined in analytical problem solving, agile collaboration, and continuous learning. Eager to leverage proven technical abilities and work ethic to deliver immediate value in a collaborative, growth-oriented team environment.`;
    }

    // 15. Default: Full Stack / General Software Engineer or Clean Universal Role
    if (normalized.includes('software') || normalized.includes('full stack') || normalized.includes('fullstack') || normalized.includes('web dev') || normalized.includes('developer')) {
      return `Results-driven Full Stack Software Engineer with ${exp} designing, building, and deploying scalable web applications, RESTful microservices, and modern user experiences. Proficient in JavaScript, TypeScript, React, Node.js, and SQL, with a track record of driving system performance optimizations, reducing deployment latency by 40%, and collaborating across cross-functional teams to deliver customer-centric, production-ready solutions.`;
    }

    // Generic Professional matching the user's specific role title
    return `Results-driven and strategic ${inputRole} with ${exp} driving operational excellence, executing high-priority initiatives, and delivering measurable business outcomes. Recognized for strong analytical problem-solving, stakeholder collaboration, and process optimization. Adept at leveraging modern industry methodologies to streamline workflows, enhance productivity by 30%, and exceed target performance benchmarks.`;
  };

  return await generateAIContent(prompt, systemInstruction, fallback);
}

/**
 * Project Description Improver (STAR Method, Action Verbs, Metrics)
 */
async function improveProject({ projectName, description, technologies, role }) {
  const tech = technologies || 'modern development tools';
  const name = projectName || 'Key Project';

  const systemInstruction = `You are a technical resume optimization expert. Transform casual project descriptions into 2-3 ATS-compliant bullet points using the STAR method (Situation, Task, Action, Result). Start each bullet with a powerful past-tense action verb (e.g., Architected, Engineered, Implemented, Streamlined, Spearheaded). Include realistic quantifiable metrics. Do not add introductory chit-chat.`;

  const prompt = `Improve this resume project:
Project Name: ${name}
Current Description / Notes: ${description || 'Executed project initiatives'}
Technologies: ${tech}
Target Role: ${role || 'Technical Professional'}

Return 2 to 3 bullet points starting with '• ' that showcase technical depth, problem-solving, and measurable results.`;

  const fallback = () => {
    return `• Spearheaded the design and deployment of ${name} utilizing ${tech}, improving process turnaround time and operational throughput by 42%.\n• Engineered robust data structures and modular workflows, supporting 10,000+ active user interactions with 99.8% reliability.\n• Implemented quality assurance benchmarks and automated pipelines, reducing defect rates and review cycles by 30%.`;
  };

  return await generateAIContent(prompt, systemInstruction, fallback);
}

/**
 * Experience Description Improver
 */
async function improveExperience({ jobTitle, company, description, achievements }) {
  const title = jobTitle || 'Professional';
  const comp = company || 'Organization';

  const systemInstruction = `You are an executive resume strategist. Rewrite work experience descriptions into 3-4 high-impact ATS-friendly bullet points using strong action verbs, technical leadership, and quantified outcomes (percentages, team scale, speed improvements). Format as bullet points starting with '• '. No conversational preamble.`;

  const prompt = `Rewrite this work experience for a resume:
Title: ${title}
Company: ${comp}
Raw Description: ${description || 'Managed core responsibilities'}
Achievements: ${achievements || 'Improved team efficiency'}

Ensure high ATS keyword density, strong action verbs, and clear commercial impact.`;

  const fallback = () => {
    return `• Spearheaded execution of core strategic initiatives at ${comp}, driving a 28% increase in operational efficiency and performance benchmarks.\n• Analyzed existing workflows and engineered optimized solutions, reducing turnaround latency by 35% across key deliverables.\n• Collaborated cross-functionally with senior leadership and team members to deliver high-visibility projects on time and within budget.\n• Mentored team colleagues on industry best practices, quality standards, and continuous improvement protocols.`;
  };

  return await generateAIContent(prompt, systemInstruction, fallback);
}

/**
 * Career Objective Generator (Great for Students / Fresh Grads)
 */
async function generateCareerObjective({ targetRole, degree, interests, skills }) {
  const role = targetRole || 'Associate Professional';
  const deg = degree || 'Bachelor’s Degree';
  const sk = skills || 'analytical problem solving, domain expertise, and technical collaboration';

  const systemInstruction = `You are an expert career counselor. Write an ATS-friendly, forward-looking 2-3 sentence career objective tailored for a candidate pursuing: "${role}". Highlight foundational competence, enthusiasm, and dedication to adding tangible business value.`;

  const prompt = `Generate a career objective for:
Target Position: ${role}
Degree/Education: ${deg}
Key Competencies: ${sk}
Interests: ${interests || 'Professional excellence, modern technologies, and high-impact teamwork'}`;

  const fallback = () => {
    return `Ambitious and analytical ${deg} graduate seeking to leverage strong foundational skills in ${sk} as a ${role}. Dedicated to continuous professional growth, rapid mastery of emerging methodologies, and contributing to high-impact organizational initiatives in a collaborative, fast-paced environment.`;
  };

  return await generateAIContent(prompt, systemInstruction, fallback);
}

/**
 * Skill Expansion & Categorization
 */
async function improveSkill({ skillCategory, currentSkills }) {
  const cat = skillCategory || 'Technical';
  const skills = currentSkills || '';

  const prompt = `Given the skill category "${cat}" and current entries "${skills}", suggest an expanded, highly professional, ATS-optimized list of 8-12 relevant, in-demand industry standard skills/tools. Return as a comma-separated list only.`;

  const fallback = () => {
    const c = cat.toLowerCase();
    if (c.includes('data') || c.includes('anal')) {
      return `SQL, Python, Tableau, Power BI, Excel (Pivot Tables, VLOOKUP), ETL Pipelines, Data Modeling, Google Analytics, R, Statistics`;
    }
    if (c.includes('technical') || c.includes('program') || c.includes('code')) {
      return `JavaScript, TypeScript, Python, RESTful APIs, Git, PostgreSQL, Docker, Jest, CI/CD, React, Node.js`;
    }
    if (c.includes('cloud') || c.includes('devops')) {
      return `Docker, Kubernetes, AWS (S3, EC2), Terraform, CI/CD Pipelines, Linux, GitHub Actions, Nginx, Prometheus, Grafana`;
    }
    if (c.includes('design') || c.includes('ux') || c.includes('ui')) {
      return `Figma, Adobe XD, Wireframing, Rapid Prototyping, Design Systems, User Research, Usability Testing, Information Architecture`;
    }
    return `Strategic Planning, Cross-Functional Collaboration, Problem Solving, Agile Scrum, Data-Driven Decision Making, Communication`;
  };

  return await generateAIContent(prompt, 'You are an ATS technical skills advisor. Provide concise comma-separated skills only.', fallback);
}

module.exports = {
  generateSummary,
  improveProject,
  improveExperience,
  generateCareerObjective,
  improveSkill,
  generateAIContent
};
