const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const RESUMES_FILE = path.join(DATA_DIR, 'resumes.json');
const ATS_FILE = path.join(DATA_DIR, 'ats_results.json');
const USERS_FILE = path.join(DATA_DIR, 'users.json');

// Ensure data folder and files exist
function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(RESUMES_FILE)) {
    fs.writeFileSync(RESUMES_FILE, JSON.stringify(getDefaultResumes(), null, 2));
  }
  if (!fs.existsSync(ATS_FILE)) {
    fs.writeFileSync(ATS_FILE, JSON.stringify([], null, 2));
  }
  if (!fs.existsSync(USERS_FILE)) {
    fs.writeFileSync(USERS_FILE, JSON.stringify([], null, 2));
  }
}

function readJSON(file) {
  try {
    ensureDataDir();
    const data = fs.readFileSync(file, 'utf8');
    return JSON.parse(data || '[]');
  } catch (err) {
    console.error(`Error reading ${file}:`, err);
    return [];
  }
}

function writeJSON(file, data) {
  try {
    ensureDataDir();
    fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (err) {
    console.error(`Error writing ${file}:`, err);
    return false;
  }
}

function getDefaultResumes() {
  return [
    {
      id: 'demo-resume-1',
      userId: 'demo-user',
      resumeName: 'Full Stack Software Engineer',
      template: 'modern',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      atsScore: 88,
      personalInfo: {
        fullName: 'Alex Morgan',
        title: 'Full Stack Software Engineer',
        email: 'alex.morgan@email.com',
        phone: '+1 (555) 234-5678',
        location: 'San Francisco, CA',
        linkedin: 'https://linkedin.com/in/alexmorgan',
        github: 'https://github.com/alexmorgan',
        portfolio: 'https://alexmorgan.dev'
      },
      summary: 'Results-driven Full Stack Engineer with 3+ years of experience designing and implementing scalable web applications, RESTful APIs, and cloud-native solutions. Proficient in JavaScript, TypeScript, React, Node.js, and PostgreSQL with a proven record of optimizing database performance by 40% and delivering robust microservices.',
      education: [
        {
          id: 'edu-1',
          degree: 'Bachelor of Science in Computer Science',
          institution: 'University of California, Berkeley',
          location: 'Berkeley, CA',
          startYear: '2019',
          endYear: '2023',
          grade: '3.85 GPA'
        }
      ],
      skills: {
        technical: 'JavaScript, TypeScript, Python, HTML5, CSS3, SQL',
        frameworks: 'React, Node.js, Express.js, Next.js, Tailwind CSS',
        tools: 'Git, Docker, AWS (S3, EC2), Postman, Jest, CI/CD',
        soft: 'Problem Solving, Agile Collaboration, Technical Mentorship, Cross-functional Communication'
      },
      projects: [
        {
          id: 'proj-1',
          name: 'AI Document Intelligence Platform',
          technologies: 'Node.js, Express, React, OpenAI API, MongoDB, AWS',
          link: 'https://aidocintel.demo.com',
          github: 'https://github.com/alexmorgan/ai-doc-intel',
          description: 'Architected and deployed an end-to-end AI document classification pipeline supporting 15,000+ monthly uploads. Reduced document processing time by 65% through async BullMQ workers and integrated Redis caching.'
        },
        {
          id: 'proj-2',
          name: 'Real-Time Collaborative Code Editor',
          technologies: 'WebSockets, React, Node.js, Monaco Editor, Docker',
          link: 'https://codeshare-live.demo.com',
          github: 'https://github.com/alexmorgan/codeshare-live',
          description: 'Engineered a multi-user collaborative workspace with Operational Transformation (OT) supporting up to 50 concurrent active editors per room with sub-50ms latency.'
        }
      ],
      experience: [
        {
          id: 'exp-1',
          title: 'Software Engineer',
          company: 'Nexus Cloud Technologies',
          location: 'San Francisco, CA',
          startDate: 'Jun 2023',
          endDate: 'Present',
          description: 'Developed and maintained 12+ mission-critical microservices serving 200,000+ daily active users. Streamlined CI/CD deployment pipelines cutting staging deployment duration from 25 minutes to 7 minutes.'
        },
        {
          id: 'exp-2',
          title: 'Software Engineering Intern',
          company: 'Apex Data Labs',
          location: 'San Jose, CA',
          startDate: 'May 2022',
          endDate: 'Aug 2022',
          description: 'Designed interactive analytical dashboards using React and D3.js. Refactored legacy REST endpoints in Express resulting in a 35% reduction in API response latency.'
        }
      ],
      certifications: [
        {
          id: 'cert-1',
          name: 'AWS Certified Solutions Architect – Associate',
          organization: 'Amazon Web Services',
          date: '2024',
          link: 'https://aws.amazon.com/verification'
        }
      ],
      achievements: [
        {
          id: 'ach-1',
          title: '1st Place Winner – HackTech 2023',
          description: 'Awarded first place among 120 teams for building an accessible AI-powered speech navigation assistant.'
        }
      ]
    },
    {
      id: 'demo-resume-2',
      userId: 'demo-user',
      resumeName: 'Frontend Developer & UI Engineer',
      template: 'creative',
      createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
      updatedAt: new Date(Date.now() - 86400000).toISOString(),
      atsScore: 82,
      personalInfo: {
        fullName: 'Sarah Chen',
        title: 'Frontend Developer & UI Specialist',
        email: 'sarah.chen@designcode.io',
        phone: '+1 (555) 891-2345',
        location: 'Seattle, WA',
        linkedin: 'https://linkedin.com/in/sarahchendev',
        github: 'https://github.com/sarahchendev',
        portfolio: 'https://sarahchen.design'
      },
      summary: 'Passionate Frontend Developer focused on building accessible, high-performance web applications with modern design systems and intuitive user experiences. Experienced in React, JavaScript, modern CSS, Web Vitals optimization, and state management.',
      education: [
        {
          id: 'edu-2',
          degree: 'B.S. in Software Engineering',
          institution: 'University of Washington',
          location: 'Seattle, WA',
          startYear: '2020',
          endYear: '2024',
          grade: '3.90 GPA'
        }
      ],
      skills: {
        technical: 'JavaScript (ES6+), TypeScript, HTML5 semantic markup, CSS3/SCSS',
        frameworks: 'React, Next.js, Redux Toolkit, Tailwind CSS, Material UI',
        tools: 'Figma, Git, Vite, Webpack, Lighthouse, Jest, Cypress',
        soft: 'Design Systems, User Advocacy, Agile Scrum, Sprint Planning'
      },
      projects: [
        {
          id: 'proj-3',
          name: 'FinTrack - Personal Finance SaaS',
          technologies: 'React, Tailwind CSS, Chart.js, JWT Authentication',
          link: 'https://fintrack.app',
          github: 'https://github.com/sarahchendev/fintrack',
          description: 'Constructed responsive dashboard featuring interactive financial projection charts and automated budgeting alerts. Achieved 98+ Google Lighthouse Performance score.'
        }
      ],
      experience: [
        {
          id: 'exp-3',
          title: 'Frontend Developer Intern',
          company: 'Luminate Digital',
          location: 'Seattle, WA',
          startDate: 'Jan 2024',
          endDate: 'Jun 2024',
          description: 'Implemented component library in React adhering to WCAG 2.1 AA accessibility guidelines. Increased mobile user retention by 22% via responsive optimization.'
        }
      ],
      certifications: [
        {
          id: 'cert-2',
          name: 'Meta Frontend Developer Professional Certificate',
          organization: 'Meta / Coursera',
          date: '2023',
          link: 'https://coursera.org/verify/frontend'
        }
      ],
      achievements: [
        {
          id: 'ach-2',
          title: 'Dean’s Honor List (4 Consecutive Semesters)',
          description: 'Recognized for top 5% academic performance in School of Computer Science.'
        }
      ]
    }
  ];
}

module.exports = {
  ensureDataDir,
  getResumes: (userId) => {
    const list = readJSON(RESUMES_FILE);
    if (!userId) return list;
    return list.filter(r => r.userId === userId || r.userId === 'demo-user');
  },
  getResumeById: (id) => {
    const list = readJSON(RESUMES_FILE);
    return list.find(r => r.id === id);
  },
  saveResume: (resumeData) => {
    const list = readJSON(RESUMES_FILE);
    const existingIndex = list.findIndex(r => r.id === resumeData.id);
    const now = new Date().toISOString();
    
    if (existingIndex >= 0) {
      list[existingIndex] = {
        ...list[existingIndex],
        ...resumeData,
        updatedAt: now
      };
      writeJSON(RESUMES_FILE, list);
      return list[existingIndex];
    } else {
      const newResume = {
        ...resumeData,
        id: resumeData.id || 'res-' + Date.now(),
        createdAt: now,
        updatedAt: now
      };
      list.unshift(newResume);
      writeJSON(RESUMES_FILE, list);
      return newResume;
    }
  },
  deleteResume: (id) => {
    const list = readJSON(RESUMES_FILE);
    const filtered = list.filter(r => r.id !== id);
    writeJSON(RESUMES_FILE, filtered);
    return true;
  },
  saveATSResult: (result) => {
    const list = readJSON(ATS_FILE);
    const record = {
      ...result,
      id: result.id || 'ats-' + Date.now(),
      createdAt: new Date().toISOString()
    };
    list.unshift(record);
    writeJSON(ATS_FILE, list);
    return record;
  },
  getATSResults: (resumeId) => {
    const list = readJSON(ATS_FILE);
    if (resumeId) return list.filter(r => r.resumeId === resumeId);
    return list;
  },
  getDefaultResumes
};
