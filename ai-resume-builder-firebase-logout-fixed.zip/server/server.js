const express = require('express');
const cors = require('cors');
const compression = require('compression');
const path = require('path');
const dotenv = require('dotenv');

// Load environment variables from .env if present
dotenv.config();

const dbService = require('./services/db.service');
const aiRoutes = require('./routes/ai.routes');
const atsRoutes = require('./routes/ats.routes');
const jobRoutes = require('./routes/job.routes');
const resumeRoutes = require('./routes/resume.routes');

const app = express();
const PORT = process.env.PORT || 3000;

// Initialize data persistence directory
dbService.ensureDataDir();

// Performance Middleware: Enable Gzip / Deflate compression for all responses
app.use(compression({
  threshold: 512, // Compress anything larger than 512 bytes
  filter: (req, res) => {
    if (req.headers['x-no-compression']) return false;
    return compression.filter(req, res);
  }
}));

// Standard Middlewares
app.use(cors());
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

// Static frontend files with no-cache headers for scripts/pages during development
const rootDir = path.join(__dirname, '..');
app.use(express.static(rootDir, {
  etag: true,
  lastModified: true,
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.html') || filePath.endsWith('.js') || filePath.endsWith('.css')) {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
    }
  }
}));

// API Routes
app.use('/api/ai', aiRoutes);
app.use('/api/ats', atsRoutes);
app.use('/api/job', jobRoutes);
app.use('/api/resume', resumeRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    timestamp: new Date().toISOString(),
    aiProvider: process.env.GEMINI_API_KEY ? 'Google Gemini' : (process.env.OPENAI_API_KEY ? 'OpenAI' : 'Built-in Smart Heuristic AI Engine')
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Unhandled Server Error:', err);
  res.status(500).json({
    success: false,
    message: err.message || 'Internal Server Error'
  });
});

// Fallback to index.html for root page or static paths
app.get('/', (req, res) => {
  res.sendFile(path.join(rootDir, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`=======================================================`);
  console.log(`🚀 AI Resume Builder with ATS Score Analyzer is RUNNING!`);
  console.log(`📍 Web Application URL: http://localhost:${PORT}`);
  console.log(`🤖 AI Engine Status: ${process.env.GEMINI_API_KEY ? 'Gemini API active' : (process.env.OPENAI_API_KEY ? 'OpenAI API active' : 'Smart Heuristic Engine active')}`);
  console.log(`=======================================================`);
});
