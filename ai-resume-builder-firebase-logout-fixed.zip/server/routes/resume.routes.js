// server/routes/resume.routes.js
const express = require('express');
const router = express.Router();
const resumeController = require('../controllers/resume.controller');

router.post('/', resumeController.saveResume);
router.get('/', resumeController.getUserResumes);
router.get('/:id', resumeController.getResumeById);
router.put('/:id', resumeController.updateResume);
router.delete('/:id', resumeController.deleteResume);

module.exports = router;
