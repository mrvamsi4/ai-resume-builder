// server/routes/ats.routes.js
const express = require('express');
const router = express.Router();
const multer = require('multer');
const atsController = require('../controllers/ats.controller');

// Configure multer with memory storage and 10MB limit
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }
});

router.post('/analyze', atsController.analyzeResume);
router.post('/upload-and-analyze', upload.single('resumeFile'), atsController.uploadAndAnalyze);

module.exports = router;
