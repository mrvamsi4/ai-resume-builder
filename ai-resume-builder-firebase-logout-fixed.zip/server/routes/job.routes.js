// server/routes/job.routes.js
const express = require('express');
const router = express.Router();
const jobController = require('../controllers/job.controller');

router.post('/match', jobController.matchJob);

module.exports = router;
