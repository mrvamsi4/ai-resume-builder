// server/routes/ai.routes.js
const express = require('express');
const router = express.Router();
const aiController = require('../controllers/ai.controller');

router.post('/generate-summary', aiController.generateSummary);
router.post('/improve-project', aiController.improveProject);
router.post('/improve-experience', aiController.improveExperience);
router.post('/improve-skill', aiController.improveSkill);
router.post('/career-objective', aiController.generateCareerObjective);
router.post('/general', aiController.generateGeneral);

module.exports = router;
