// server/controllers/ai.controller.js
const aiService = require('../services/ai.service');

exports.generateSummary = async (req, res) => {
  try {
    const { role, experienceYears, skills, background, tone } = req.body;
    const summary = await aiService.generateSummary({ role, experienceYears, skills, background, tone });
    return res.json({ success: true, summary });
  } catch (err) {
    console.error('Error generating summary:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

exports.improveProject = async (req, res) => {
  try {
    const { projectName, description, technologies, role } = req.body;
    const improvedDescription = await aiService.improveProject({ projectName, description, technologies, role });
    return res.json({ success: true, improvedDescription });
  } catch (err) {
    console.error('Error improving project:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

exports.improveExperience = async (req, res) => {
  try {
    const { jobTitle, company, description, achievements } = req.body;
    const improvedExperience = await aiService.improveExperience({ jobTitle, company, description, achievements });
    return res.json({ success: true, improvedExperience });
  } catch (err) {
    console.error('Error improving experience:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

exports.improveSkill = async (req, res) => {
  try {
    const { skillCategory, currentSkills } = req.body;
    const expandedSkills = await aiService.improveSkill({ skillCategory, currentSkills });
    return res.json({ success: true, expandedSkills });
  } catch (err) {
    console.error('Error expanding skills:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

exports.generateCareerObjective = async (req, res) => {
  try {
    const { targetRole, degree, interests, skills } = req.body;
    const objective = await aiService.generateCareerObjective({ targetRole, degree, interests, skills });
    return res.json({ success: true, objective });
  } catch (err) {
    console.error('Error generating career objective:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

exports.generateGeneral = async (req, res) => {
  try {
    const { prompt, context } = req.body;
    if (!prompt) {
      return res.status(400).json({ success: false, message: 'Prompt is required' });
    }
    const result = await aiService.generateAIContent(prompt, context);
    return res.json({ success: true, result });
  } catch (err) {
    console.error('Error in general generation:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};
