// server/controllers/resume.controller.js
const dbService = require('../services/db.service');
const atsService = require('../services/ats.service');

exports.saveResume = (req, res) => {
  try {
    const resumeData = req.body;
    if (!resumeData) {
      return res.status(400).json({ success: false, message: 'Resume data is required' });
    }

    // Auto-calculate ATS score if not already present
    if (!resumeData.atsScore) {
      const analysis = atsService.analyzeStructuredResume(resumeData);
      resumeData.atsScore = analysis.score;
    }

    const saved = dbService.saveResume(resumeData);
    return res.json({ success: true, resume: saved });
  } catch (err) {
    console.error('Error saving resume:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

exports.getResumeById = (req, res) => {
  try {
    const { id } = req.params;
    const resume = dbService.getResumeById(id);
    if (!resume) {
      return res.status(404).json({ success: false, message: 'Resume not found' });
    }
    return res.json({ success: true, resume });
  } catch (err) {
    console.error('Error fetching resume:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

exports.getUserResumes = (req, res) => {
  try {
    const userId = req.query.userId;
    const resumes = dbService.getResumes(userId);
    return res.json({ success: true, resumes });
  } catch (err) {
    console.error('Error fetching resumes:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

exports.updateResume = (req, res) => {
  try {
    const { id } = req.params;
    const resumeData = { ...req.body, id };

    // Auto-recalculate ATS score
    const analysis = atsService.analyzeStructuredResume(resumeData);
    resumeData.atsScore = analysis.score;

    const updated = dbService.saveResume(resumeData);
    return res.json({ success: true, resume: updated });
  } catch (err) {
    console.error('Error updating resume:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

exports.deleteResume = (req, res) => {
  try {
    const { id } = req.params;
    dbService.deleteResume(id);
    return res.json({ success: true, message: 'Resume deleted successfully' });
  } catch (err) {
    console.error('Error deleting resume:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};
