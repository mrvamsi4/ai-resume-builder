// server/controllers/ats.controller.js
const atsService = require('../services/ats.service');
const dbService = require('../services/db.service');
const pdfParse = require('pdf-parse');

exports.analyzeResume = async (req, res) => {
  try {
    const { resume, jobDescription } = req.body;
    if (!resume) {
      return res.status(400).json({ success: false, message: 'Resume object or data is required' });
    }

    const analysis = atsService.analyzeStructuredResume(resume, jobDescription);
    
    // Save record to DB if resume has an ID
    if (resume.id) {
      dbService.saveATSResult({
        resumeId: resume.id,
        score: analysis.score,
        categories: analysis.categories,
        statusText: analysis.statusText,
        strengths: analysis.strengths,
        warnings: analysis.warnings,
        suggestions: analysis.suggestions
      });
    }

    return res.json({ success: true, analysis });
  } catch (err) {
    console.error('Error analyzing resume:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

exports.uploadAndAnalyze = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'No resume PDF file uploaded' });
    }

    const jobDescription = req.body.jobDescription || '';

    // Extract text from PDF buffer
    let resumeText = '';
    try {
      const parsed = await pdfParse(req.file.buffer);
      resumeText = parsed.text;
    } catch (parseErr) {
      console.warn('PDF parsing error, attempting text conversion:', parseErr);
      resumeText = req.file.buffer.toString('utf-8');
    }

    if (!resumeText || resumeText.trim().length < 20) {
      return res.status(400).json({
        success: false,
        message: 'Could not extract readable text from the uploaded file. Please ensure it is not a scanned image without OCR.'
      });
    }

    const structuredResume = atsService.parseRawResumeText(resumeText);
    const analysis = atsService.analyzeStructuredResume(structuredResume, jobDescription);

    return res.json({
      success: true,
      extractedTextSample: resumeText.slice(0, 500) + '...',
      parsedResume: structuredResume,
      analysis
    });
  } catch (err) {
    console.error('Error handling resume upload:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};
