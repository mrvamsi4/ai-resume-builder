// server/controllers/job.controller.js
const atsService = require('../services/ats.service');

exports.matchJob = async (req, res) => {
  try {
    const { resume, jobTitle, company, jobDescription } = req.body;

    if (!jobDescription || jobDescription.trim().length < 10) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a job description to perform match analysis.'
      });
    }

    // If resume is empty, create a dummy or analyze against empty
    const resumeObj = resume || {
      skills: {},
      summary: '',
      projects: [],
      experience: []
    };

    const analysis = atsService.analyzeStructuredResume(resumeObj, jobDescription);

    const matchPercentage = analysis.categories.jobMatch || 70;

    return res.json({
      success: true,
      jobTitle: jobTitle || 'Target Position',
      company: company || 'Hiring Company',
      matchPercentage,
      matchingSkills: analysis.matchingSkills,
      missingSkills: analysis.missingSkills,
      recommendedKeywords: analysis.recommendedKeywords,
      suggestions: analysis.suggestions,
      statusBadge: analysis.statusBadge
    });
  } catch (err) {
    console.error('Error in job match:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};
