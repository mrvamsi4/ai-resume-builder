# ResumeAI - AI Resume Builder with ATS Score Analyzer 🚀

A modern, responsive, full-stack web application designed for students, fresh graduates, and job seekers to create professional resumes, generate recruiter-ready content with Generative AI, analyze ATS compatibility with explainable scoring, inspect job description alignment, preview 6+ ATS-compliant templates in real time, and download vector-crisp A4 PDFs.

---

## 🌟 Key Highlights & Features

### 1. 🛠️ Dynamic Multi-Section Resume Builder
- **Personal Information**: Full Name, Target Title, Email, Phone, Location, LinkedIn, GitHub, Portfolio.
- **Professional Summary**: Direct generative AI integration with instant bullet or paragraph modes.
- **Dynamic Modular Forms**: Add/remove multiple entries seamlessly for:
  - 🎓 **Education**: Degree, Institution, Location, Graduation Year, CGPA/Percentage.
  - ⚡ **Categorized Skills**: Technical Skills, Languages, Tools, Frameworks, Soft Competencies.
  - 💻 **Key Technical Projects**: Title, Tech Stack, Live Link, GitHub Link, AI STAR-method bullet optimizer.
  - 💼 **Professional Experience**: Job Title, Company, Dates, Location, AI-enhanced impact statements.
  - 📜 **Certifications**: Credential Name, Issuing Org, Year, Verification URL.
  - 🏆 **Achievements & Honors**: Title and context.
- **Sample Data Loader**: Pre-loads rich, realistic candidate data in one click for instant demonstration!

### 2. 🤖 Secure Backend AI Content Assistant
- Integrates **Google Gemini API** (e.g. `gemini-1.5-flash`) and **OpenAI API** (`gpt-4o-mini`).
- API keys are **strictly guarded on the Node.js backend** and are never exposed to the client.
- Built-in **Smart Heuristic Resume Engine**: works immediately even if no API key is provided, generating realistic, metric-driven bullet points with zero configuration!
- Features: Generate Summary, STAR-method Project Optimizer, Work Experience Enhancer, Career Objective Writer, and Skills Expansion.

### 3. 🎯 Explainable ATS Score Analyzer & Job Matcher
- **100-Point Scoring Model** with transparent category weightings:
  - 🔑 **Keyword Density & Relevance (30%)**
  - ⚡ **Technical Skills Match (20%)**
  - 📋 **Resume Section Completeness (15%)**
  - 📐 **Formatting & Action Verbs (15%)**
  - 📖 **Readability & Length Optimization (10%)**
  - 🎯 **Target Job Posting Alignment (10%)**
- **Circular Animated Score Progress Meter** with color-coded status badges.
- **Checklist Breakdown**:
  - `✓` Verified Strengths
  - `⚠` Actionable Warnings & Suggested Improvements
- **Resume Input Flexibility**:
  - Direct selection of resumes created in the Builder
  - Upload of external PDF resumes with automated server text extraction!
- **Job Description Gap Analysis**:
  - Paste any job posting (Job Title, Company, Requirements)
  - Computes Match Percentage
  - Visual chips for **Matching Skills** (green), **Missing Skills** (red), and **Recommended ATS Keywords** (blue).

### 4. 🎨 6+ Recruiter-Approved Resume Templates
- **Modern Tech**: Contemporary indigo accent, organized skills chips, crisp sans-serif.
- **Corporate Professional**: Classic corporate navy blue titles, horizontal rules, elegant serif headers.
- **Minimalist Clean**: Monochromatic high-whitespace layout optimized for automated scanners.
- **Creative Impact**: Gradient header banner with prominent portfolio links and skill badges.
- **Executive Leadership**: Emerald/slate corporate styling with distinguished executive summary.
- **ATS Classic (Universal Standard)**: Strict single-column standard formatting with universal font compatibility.

### 5. 📄 Live A4 Resume Preview & High-Fidelity PDF
- Keystroke-level synchronization between form editor and live preview.
- Canvas zoom controls (75%, 95%, 110%, 125%).
- Seamless real-time template switching.
- **A4 PDF Export**: Built with `html2pdf.js` for vector-crisp typography, accurate margins, and selectable text.
- Full `@media print` support for browser printing.

### 6. 🔐 Local Email/Password Authentication & Data Persistence
- Uses a lightweight local email/password session adapter with LocalStorage.
- No external OAuth provider or third-party authentication SDK is required.
- Resume data is persisted through the Express backend with LocalStorage fallback.

### 1. Prerequisites
- Node.js (v18 or higher recommended; portable Node.js v20.18.0 included in workspace).

### 2. Installation
Clone or navigate to the project directory and install backend dependencies:
```bash
cd ai-resume-builder
npm install
```

### 3. Environment Variables (.env)
Copy `.env.example` to `.env` (or edit existing `.env`):
```env
PORT=3000

# Google Gemini API Key (Recommended)
# Obtain a free key from: https://aistudio.google.com/
GEMINI_API_KEY=your_gemini_api_key_here

# OR OpenAI API Key
# Obtain from: https://platform.openai.com/api-keys
OPENAI_API_KEY=your_openai_api_key_here
```
> **Note**: If you don't supply an API key right now, the application will automatically activate its built-in **Smart Heuristic Resume AI Engine**, so all features work 100% out of the box!

### 4. Running the Application
Start the Express server:
```bash
npm start
```
You will see:
```
=======================================================
🚀 AI Resume Builder with ATS Score Analyzer is RUNNING!
📍 Web Application URL: http://localhost:3000
🤖 AI Engine Status: Active
=======================================================
```

Open your browser and navigate to:
```
http://localhost:3000
```

---

## 🔐 Authentication
External OAuth authentication has been removed from this version.

The application uses its local email/password session adapter and Express backend. No Firebase project configuration is required.

## 🧪 Testing the Complete Workflow

1. **Landing Page**:
   - Open `http://localhost:3000`.
   - Click **"Build My Resume"** or **"Analyze My Resume"**.
2. **One-Click Demo Login**:
   - Navigate to `login.html`.
   - Click the button **"⚡ One-Click Demo Account Login"** to immediately sign in as Alex Morgan.
3. **Dashboard**:
   - View your metrics (Total Resumes, Average ATS Score, Completeness %).
   - Inspect the pre-loaded resumes and click **"Edit"** or **"Preview & PDF"**.
4. **Resume Builder**:
   - Try typing in any field: notice the right-hand **A4 paper preview synchronizes in real time**!
   - Click **"Sample Data"** to load a full resume.
   - Click **"✨ AI Assistant"** on the summary, projects, or experience to generate bullet points.
   - Use the **Template dropdown** to switch between all 6 styles (Modern, Professional, Minimal, Creative, Executive, ATS Classic).
   - Click **"📥 Download PDF"** to export an authentic A4 PDF.
5. **ATS Score Analyzer**:
   - Navigate to `analyzer.html`.
   - Select your resume or upload a PDF resume.
   - Observe the **animated circular gauge** calculate your ATS score out of 100.
   - Inspect the 6 category breakdown bars and the **Strengths (`✓`)** and **Improvement Warnings (`⚠`)**.
   - Paste a sample Job Description into the **Job Description Matching** section to see matching and missing technical skills.
6. **Templates & Settings**:
   - Browse `templates.html` and click **"Use This Template"**.
   - Switch to **Dark Mode** in `settings.html`.

---

## 🛡️ Security & Best Practices

- **Backend API Protection**: Gemini and OpenAI API keys never leak to frontend scripts.
- **Input Sanitization**: HTML escaping guards against XSS injections.
- **Fail-Safe Fallbacks**: No third-party network failure can crash the user interface.
- **Privacy-Centric**: User data is isolated per account.

---

## 📜 License
This project is open-source under the [MIT License](LICENSE).


## Firebase Authentication Setup

This version uses **Firebase Authentication** instead of the previous localStorage-only mock authentication.

### 1. Create a Firebase project
1. Open the Firebase Console: https://console.firebase.google.com/
2. Create/select your project.
3. Go to **Project settings → Your apps → Web app** and register a web app.
4. Copy the Firebase Web SDK configuration.

### 2. Enable sign-in providers
Go to **Authentication → Sign-in method** and enable:
- **Email/Password**
- **Google** (for the Google button)

### 3. Add your Firebase config
Open `js/firebase-config.js` and replace the `YOUR_...` placeholders with your Firebase Web App configuration.

### 4. Authorize domains
In Firebase Console → Authentication → Settings → Authorized domains, add:
- `localhost`
- your production domain (Vercel/Netlify/etc.)

### 5. Run
```bash
npm install
npm start
```
Open `http://localhost:3000`.

### Included
- Firebase Email/Password registration and login
- Google Sign-In
- Password reset email
- Firebase session persistence
- Protected dashboard/builder/profile/settings/analyzer pages
- Existing `AppAuth` interface preserved
- Firebase ID token attached to resume save/delete requests

> Firebase Web API keys are designed for browser apps. Do not put a Firebase Admin SDK service-account private key in frontend files.

## Firebase project configured
This build is configured for the Firebase project `resumeai-d2498`. Enable **Email/Password** and **Google** under Firebase Console → Authentication → Sign-in method. Add your local/deployed domains under Authentication → Settings → Authorized domains.
