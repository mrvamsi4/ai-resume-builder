// test-roles.js
const aiService = require('./server/services/ai.service');

async function testAllRoles() {
  const roles = [
    'Data analyst',
    'Frontend Developer',
    'DevOps Engineer',
    'Cybersecurity Analyst',
    'UI/UX Designer',
    'Product Manager',
    'Business Analyst',
    'Fresher / Graduate',
    'Financial Analyst',
    'Human Resources (HR)'
  ];

  console.log('=== TESTING AI SUMMARY GENERATION FOR MULTIPLE ROLES ===\n');

  for (const role of roles) {
    const summary = await aiService.generateSummary({
      role: role,
      skills: '',
      background: role
    });
    console.log(`[Role]: ${role}`);
    console.log(`[Summary]: ${summary}\n`);
  }
}

testAllRoles();
