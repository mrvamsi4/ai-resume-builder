// test-api.js
async function runTests() {
  const baseUrl = 'http://localhost:3000';
  console.log('--- Starting API Verification Tests ---');

  // 1. Health
  try {
    const res = await fetch(`${baseUrl}/api/health`);
    const data = await res.json();
    console.log('✓ /api/health:', data);
  } catch (e) {
    console.error('✗ /api/health failed:', e.message);
  }

  // 2. AI Summary
  try {
    const res = await fetch(`${baseUrl}/api/ai/generate-summary`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        role: 'Full Stack Engineer',
        skills: 'Node.js, Express, React, PostgreSQL',
        experienceYears: 3
      })
    });
    const data = await res.json();
    console.log('✓ /api/ai/generate-summary succeeded. Length:', data.summary?.length);
    console.log('  Sample:', data.summary?.slice(0, 100) + '...');
  } catch (e) {
    console.error('✗ /api/ai/generate-summary failed:', e.message);
  }

  // 3. AI Project Improvement
  try {
    const res = await fetch(`${baseUrl}/api/ai/improve-project`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        projectName: 'Restaurant Ordering App',
        technologies: 'HTML, CSS, JavaScript, Node.js',
        description: 'Built online website for food orders'
      })
    });
    const data = await res.json();
    console.log('✓ /api/ai/improve-project succeeded.');
    console.log('  Output:\n', data.improvedDescription);
  } catch (e) {
    console.error('✗ /api/ai/improve-project failed:', e.message);
  }

  // 4. ATS Score Analysis
  try {
    const res = await fetch(`${baseUrl}/api/ats/analyze`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        resume: {
          personalInfo: { fullName: 'Alex Morgan', email: 'alex@demo.com', phone: '123456789' },
          summary: 'Experienced developer with 3+ years in cloud web apps.',
          skills: { technical: 'JavaScript, TypeScript, Python, Node.js, Express, React, Docker, AWS, Git, SQL' },
          projects: [{ name: 'Cloud Platform', technologies: 'React, Node.js', description: '• Architected microservices reducing latency by 45%.' }],
          experience: [{ title: 'Software Engineer', company: 'Tech Inc', description: '• Spearheaded API redesign serving 100,000+ daily users.' }],
          education: [{ degree: 'B.S. Computer Science', institution: 'UC Berkeley' }]
        },
        jobDescription: 'Seeking Software Engineer proficient in JavaScript, React, Node.js, Docker, and REST APIs.'
      })
    });
    const data = await res.json();
    console.log('✓ /api/ats/analyze succeeded.');
    console.log('  Score:', data.analysis?.score + '/100');
    console.log('  Status:', data.analysis?.statusText);
    console.log('  Categories:', data.analysis?.categories);
    console.log('  Strengths Count:', data.analysis?.strengths?.length);
    console.log('  Warnings Count:', data.analysis?.warnings?.length);
  } catch (e) {
    console.error('✗ /api/ats/analyze failed:', e.message);
  }

  // 5. Job Description Match
  try {
    const res = await fetch(`${baseUrl}/api/job/match`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        resume: {
          skills: { technical: 'JavaScript, HTML, CSS, React, Git, Node.js' },
          summary: 'Frontend developer'
        },
        jobTitle: 'Frontend Engineer',
        company: 'Stripe',
        jobDescription: 'Requirements: JavaScript, React, TypeScript, GraphQL, REST API, Tailwind CSS, Jest'
      })
    });
    const data = await res.json();
    console.log('✓ /api/job/match succeeded.');
    console.log('  Match:', data.matchPercentage + '%');
    console.log('  Matching Skills:', data.matchingSkills);
    console.log('  Missing Skills:', data.missingSkills);
    console.log('  Recommended Keywords:', data.recommendedKeywords);
  } catch (e) {
    console.error('✗ /api/job/match failed:', e.message);
  }

  // 6. Resume CRUD
  try {
    const res = await fetch(`${baseUrl}/api/resume`);
    const data = await res.json();
    console.log('✓ /api/resume list count:', data.resumes?.length);
  } catch (e) {
    console.error('✗ /api/resume failed:', e.message);
  }

  // 7. Verify Static HTML pages exist and return 200
  const pages = ['index.html', 'login.html', 'register.html', 'dashboard.html', 'builder.html', 'analyzer.html', 'templates.html', 'profile.html', 'settings.html'];
  for (const page of pages) {
    try {
      const pageRes = await fetch(`${baseUrl}/${page}`);
      if (pageRes.status === 200) {
        console.log(`✓ GET /${page} -> 200 OK`);
      } else {
        console.error(`✗ GET /${page} -> ${pageRes.status}`);
      }
    } catch (e) {
      console.error(`✗ GET /${page} failed:`, e.message);
    }
  }

  console.log('--- All Verification Tests Completed! ---');
}

runTests();
